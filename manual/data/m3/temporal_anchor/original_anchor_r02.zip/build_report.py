#!/usr/bin/env python3
"""Compare audit modes and render the scoped validation report."""
import argparse
from fractions import Fraction as Q
import hashlib
import json
from pathlib import Path
import platform
import audit_anchor as a


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--optimized',type=Path,required=True)
    args=parser.parse_args();root=a.HERE
    first={p.name:p for p in (root/'results').iterdir() if p.is_file()}
    second={p.name:p for p in args.optimized.iterdir() if p.is_file()}
    a.s.p.require(first.keys()==second.keys(),'result file sets differ')
    hashes={}
    for name,p in sorted(first.items()):
        content=p.read_bytes()
        a.s.p.require(content==second[name].read_bytes(),'mode result differs: '+name)
        hashes[name]=hashlib.sha256(content).hexdigest()
    report=json.loads(first['report.json'].read_text())
    records=json.loads(first['admitted_validation.json'].read_text())
    rolling=json.loads(first['rolling_count_windows.json'].read_text())
    a.s.p.require(all(c['status']=='pass' for c in report['checks']),'software check failed')
    a.verify_inputs()
    f=report['frozen']
    for name,key in [('audit_anchor.py','audit_code_sha256'),('INPUT_BINDING.json','input_binding_sha256'),('VALIDATION_PROTOCOL.md','protocol_sha256')]:
        a.s.p.require(a.s.sha(root/name)==f[key],'frozen source changed: '+name)
    validation={'software_status':'pass','physical_anchor_status':'not established',
                'checks_per_mode':report['check_count'],'python':platform.python_version(),
                'modes':['normal','optimized (-O)'],'byte_identical_files':len(hashes),
                'admitted_split_windows':report['admitted_split_windows'],
                'admitted_directional_comparisons':report['admitted_directional_comparisons'],
                'rolling_count_windows':report['rolling_count_windows'],
                'endpoint_perturbation_cases':report['endpoint_perturbation_cases'],
                'sha256':hashes,'inherited_sources_unchanged':True}
    a.write(root/'validation.json',validation)
    (root/'tests.txt').write_text('\n'.join([
        'PYTHONDONTWRITEBYTECODE=1 python3 audit_anchor.py',
        'PYTHONDONTWRITEBYTECODE=1 python3 -O audit_anchor.py --output ../results-optimized',
        'PYTHONDONTWRITEBYTECODE=1 python3 build_report.py --optimized ../results-optimized',
        f'PASS: {report["check_count"]} checks per mode; {len(hashes)} output files byte-identical',
        *[c['status'].upper()+': '+c['name'] for c in report['checks']],
        'REJECTED HYPOTHESIS: fixed transferred gains for A and B across the tested half windows',
        'REJECTED HYPOTHESIS: constant cadence plus whole-count rounding for A and B across the reference-closure samples',
        'NOT ESTABLISHED: physical Cs observation law, calibration scale, uncertainty and SI anchor',
        'Inherited dynamics and manuscript bytes were not changed. This run validates diagnostics, not a new engine or repository build.','']))

    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,
                         'axes.spines.top':False,'axes.spines.right':False,
                         'axes.grid':True,'grid.alpha':.2})
    fig,axes=plt.subplots(1,2,figsize=(11.5,5.5))
    fig.subplots_adjust(left=.08,right=.97,bottom=.23,top=.75,wspace=.24)
    fig.suptitle('Cadence evolves within the declared run',fontsize=16,fontweight='bold',y=.96)
    fig.text(.5,.88,'Rolling windows of 16 F0 bips · Complete closure counts · No seconds assigned',ha='center',fontsize=10,color='#526475')
    for ax,field,title in zip(axes,('A','B'),('A: 3:3:6','B: 1:2:6')):
        for scenario,label,color in [('background_only','Shared background','#697681'),('direct_pair','Direct A ↔ B coupling','#087F8C')]:
            rows=[r for r in rolling if r['scenario']==scenario and r['reference_bips']==16]
            x=[r['start_reference_index']+16 for r in rows]
            y=[float(Q(r['fields'][field]['closures_per_F0_bip'])) for r in rows]
            ax.step(x,y,where='mid',label=label,color=color,linewidth=2)
        ax.set(title=title,xlabel='Window end: F0 bips after the first sampled closure',ylabel=field+' closures / F0 bip')
        ax.set_xticks([16,24,32,40,48,56,63])
        ax.legend(fontsize=8.5)
    fig.text(.5,.06,'F0 and F1 have identical return timings in this construction; their agreement is not independent anchor evidence.',ha='center',fontsize=9,color='#526475')
    fig.savefig(root/'cadence_validation.png',dpi=170)
    fig.savefig(root/'cadence_validation.pdf',metadata={'CreationDate':None,'ModDate':None})
    plt.close(fig)

    body=['# Temporal anchor validation — R02',
          '', 'Executed 2026-11-03. Detached audit of the prior closure/Cs/SI bridge; original dynamics, histories, reference fields and historical records are preserved.',
          '', '**The SI anchor is not established. The existing finite run rejects a fixed transferred gain for A and B, and its two nominal reference fields have identical closure timings.**',
          '', '## What the earlier percentages mean',
          '', 'The earlier −1/54 (−1.85%) and −9/62 (−14.52%) are exactly reproduced. They measure discrepancies caused by reusing a count-transfer coefficient from another coupling condition or window. They are not measured Cs frequency errors, statistical uncertainties, or a precision limit of the SI second.',
          '', 'The R01 identity g_A(ω) = κ N_R(ω)/N_A(ω) implies g_A(ω) N_A(ω) = κ N_R(ω) by construction for every positive count pair. It is a valid descriptive conversion under the declared law. Its zero route residual does not independently validate the law C_Cs(ω) = κ N_R(ω), because there is no separately measured C_Cs in these records.',
          '', '## A frozen transfer tested on a separate window',
          '', 'Each existing run is divided into calibration (300000,1808096] and validation (1808096,3316192]. Both halves contain 32 F0 reclosures. Fit g = N_F0,cal / N_i,cal using the first half only, freeze it, and predict N_F0,val from the second half’s N_i,val. The comparison target does not enter the prediction function.',
          '', '| Scenario | Field | Calibration closures | Validation closures | Frozen F0 bips / closure | Predicted validation F0 bips | Residual versus 32 F0 bips |',
          '|---|---|---:|---:|---|---|---|']
    labels={'background_only':'Shared background','direct_pair':'Direct A/B coupling','recorded_only':'Contacts recorded; feedback disabled'}
    for scenario,row in records.items():
        for field in ('A','B','F1'):
            t=row['transfers'][field];e=Q(t['comparison']['relative_residual'])
            body.append(f'| {labels[scenario]} | {field} | {row["training"]["counts"][field]} | {row["validation"]["counts"][field]} | {t["frozen"]["F0_bips_per_field_closure"]} | {t["prediction"]["predicted_F0_bips"]} | {100*float(e):.2f}% ({e}) |')
    body += ['', 'For the coupled case, A changes from 58 to 48 closures and B from 151 to 102 over equal F0-bip increments. Reusing a first-half gain consequently yields −17.24% and −32.45% count-transfer residuals. That rejects this fixed-gain specialization; it does not reject relational time or measure the accuracy of a Cs clock. The shared-background case also evolves, so the drift cannot all be attributed to enabling the direct A/B link.',
             '', 'This split is retrospective and shares a continuous dynamical history. It prevents validation-target fitting in the calculation; it is not an independent laboratory experiment or a prospective prediction.',
             '', '## Endpoint counting does not explain all the evolution',
             '', 'At all 64 retained F0 closure endpoints, test whether cumulative field counts admit y_j = floor(α x_j + β) for one fixed α > 0 and one count origin β. This explicitly allows whole-count rounding. The pairwise necessary and sufficient inequalities are',
             '', r'\[\frac{y_j-y_i-1}{x_j-x_i}<\alpha<\frac{y_j-y_i+1}{x_j-x_i}\qquad(i<j).\]',
             '', 'All are tested with rational arithmetic. For the coupled run:',
             '', '| Field | Required lower bound on α | Required upper bound on α | Constant-cadence rounding model |',
             '|---|---|---|---|']
    for field in ('A','B','F1'):
        t=records['direct_pair']['constant_cadence_rounding_tests'][field]
        body.append(f'| {field} | α > {t["strict_lower"]} | α < {t["strict_upper"]} | {"Compatible" if t["compatible"] else "Impossible"} |')
    body += ['', 'For A, early samples require α > 23/12 while later samples require α < 3/2. For B the corresponding requirements include α > 6 and α < 3. Thus an unknown count origin and integer rounding cannot make either complete series have one constant cadence. This rejects the specified rounding null; it does not rule out every possible jitter or observation model.',
             '', 'The audit also covers 588 rolling count windows (4, 8, 16 and 32 reference bips) and 216 endpoint perturbation cases. Those projections retain exact event-count bounds. They overlap and provide descriptive diagnostics, not independent samples or a standard uncertainty. Six half windows receive full temporal admission, with three directional comparisons each.',
             '', '![Cadence evolution](cadence_validation.png)',
             '', '## The reference check is degenerate for independent validation',
             '', 'F0 and F1 are distinct admitted 3:4:6 lineages, but their reclosure endpoint sequences are identical in all three retained scenarios. The reference sequence within the comparison window is also unchanged across these scenarios. Their zero discrepancy therefore gives no independent evidence of a physical anchor or robustness to perturbing the reference itself. The original construction uses symmetric reference specifications; this audit does not introduce an asymmetric perturbation or a replacement dynamics.',
             '', 'Both 3:4:6 fields, all operative coupling histories, directional RCD and lag records remain in the preserved input. Reference identity, current population and coupling state remain part of the proposed calibration domain. A generic F0 field is not identified with a Cs atom.',
             '', '## What can now be accepted',
             '', '| Claim | Disposition |',
             '|---|---|',
             '| Prior transfer discrepancies and descriptive window ratios | Reproduced exactly |',
             '| One fixed A/B-to-F0 gain transfers across these half windows | Rejected |',
             '| A/B cadence variation is only constant-cadence whole-count rounding | Rejected for the stated null |',
             '| F0/F1 equality supplies independent reference validation | Unsupported: identical endpoint histories |',
             '| Same-window symbolic conversion is internally consistent | Conditional algebra; retained |',
             '| Physical C_Cs = κ N_R observation law and calibrated κ | Not established |',
             '| Numerical physical seconds, hertz and uncertainty | Not identified |',
             '', 'The next empirical gate is a bound observation map plus synchronized Cs-referenced oscillator phase/cycle records and model reference closure events. Calibrate on a declared subset, freeze the scale and its domain, then compare separate windows and coupling conditions against measured cycles with justified uncertainty and covariance. The requirement is compatibility with a predeclared metrological tolerance, not a residual forced to zero. VALIDATION_PROTOCOL.md gives the concrete record and acceptance requirements.',
             '', 'SOURCES.md distinguishes the exact SI definition from practical realization and clock stability analysis. Neither the defining number nor the present finite simulation supplies the missing observation calibration. No isotope, TTL or shedding parameter was adjusted.',
             '', '## Reproducibility',
             '', f'{report["check_count"]} audit checks pass in normal and optimized Python. All {len(hashes)} output files are byte-identical. The inherited bridge, pair simulation, source bytes and owner plan are bound in INPUT_BINDING.json; the historical bridge is retained under baseline/.',
             '', '```bash',
             'PYTHONDONTWRITEBYTECODE=1 python3 audit_anchor.py',
             'PYTHONDONTWRITEBYTECODE=1 python3 -O audit_anchor.py --output ../results-optimized',
             'PYTHONDONTWRITEBYTECODE=1 python3 build_report.py --optimized ../results-optimized',
             '```',
             '', 'Python 3.12 and its standard library run the audit. Matplotlib renders the figure. tests.txt records software validation, including the intended rejection of scientific null hypotheses. No repository manuscript or engine was changed, so this audit makes no claim of a new Main/Manual build or current hosted PR validation.',
             '']
    (root/'README.md').write_text('\n'.join(body))
    print(json.dumps(validation,sort_keys=True))


if __name__=='__main__':main()
