# Cautious validation of the temporal anchor

This is a retrospective diagnostic audit of the existing finite simulation, bound to the prior R01 archive and its source commit. It changes no engine, motif, coupling law, RCD, gain in an existing record, or manuscript. The earlier 1.85% and 14.52% discrepancies are already known. Splitting this existing run prevents target feedback in the diagnostic calculation; it does not turn the audit into a prospective or blind experiment.

## Claims and tests

1. Reproduce both earlier transfer discrepancies from exact counts. Keep them separate from arithmetic error, empirical clock error, physical uncertainty and an SI accuracy claim.
2. Split each existing common window at its integer midpoint. Re-admit A|F0, B|F0 and F1|F0 on both halves, retaining complete histories, actual contacts, directional RCD, lag and endpoint bindings. Fit the field-to-F0 count transfer only on the first half; freeze it and apply it to the second half. Counts use (u,v]; the shared boundary event is not counted twice. Contact records may meet at the shared endpoint; no independence of the dynamical histories is assumed.
3. Check the F0 and F1 endpoint sequences rather than treating different lineage names as independent reference evidence. Distinct lineages may be synchronized by the declared construction. Equality between such traces cannot validate a laboratory calibration.
4. At every retained F0 closure, record cumulative counts of A, B and F1. Test the explicit null y_j = floor(alpha x_j + beta), alpha > 0. Here alpha is one fixed count cadence and beta is an unknown count origin. These are diagnostic report parameters, not a new phase, angle, physical clock or dynamics. For i<j the necessary and sufficient slope inequalities are (y_j-y_i-1)/(x_j-x_i) < alpha < (y_j-y_i+1)/(x_j-x_i). Intersect all inequalities and retain exact witnesses. Failure rules out this constant-cadence-plus-rounding explanation, not every possible model of measurement jitter.
5. Describe all rolling windows of 4, 8, 16 and 32 complete F0 bips. Inspect selected endpoint offsets of minus one, zero and plus one ordering cut and check exact event-count bounds. These rows are count projections from admitted histories, not separately admitted short-window RCD comparisons or SI measurements. They overlap and are not independent trials; their range is not a standard uncertainty. An ordering cut has no assigned seconds value.
6. Keep physical seconds, physical hertz, calibration scale and complete physical uncertainty unidentified. Count-route cancellation is algebra under an observation hypothesis; it is not an empirical zero residual. Preserve the prior archive as historical evidence.

## Physical anchor acceptance

The Cs defining frequency fixes the SI conversion once a corrected Cs-referenced cycle increment is known. The proposed C_Cs = kappa N_R law remains an additional observation hypothesis. A generic 3:4:6 background field is not thereby identified as Cs-133.

Before an empirical validation run, bind:

- The observable linking model reference closures to independently recorded laboratory events, including the reference field's own population, coupling and RCD context.
- The Cs-133 realization, atomic transition/interrogation configuration, oscillator and counter/divider identities, detector responses and frequency-steering records.
- Matched event windows with unwrapped oscillator cycle/phase increments. Retain fractional endpoint information where measured, or state and bound unresolved endpoint resolution. Do not infer it by inventing an intra-bip dynamics.
- Realization corrections with their evidence, calibration uncertainty, missed-cycle accounting and covariance from shared sources. Atomic population changes, detected photons and microwave oscillator cycles remain distinct observables.
- A calibration subset and separate validation windows/conditions. Estimate kappa on calibration data only, freeze its value and applicability domain, then evaluate residuals kappa N_R - C_Cs on validation records. Test actual changes to reference exposure as well as coupling of the compared fields. Retain the 3:4:6 population; any changed population or law requires an explicit new specialization.
- A numerical acceptance tolerance derived from the intended use and justified uncertainty before inspecting validation residuals. The tolerance is currently unspecified; this audit does not invent one. Assess systematic drift and window/population dependence as well as residual magnitude. Exact floating or rational equality is not the acceptance requirement for physical measurements.

At least two distinct support-pair measurement chains should be tested with their actual source dependencies recorded. A shared Cs calibration induces shared uncertainty; duplicate simulated references cannot supply independence. Do not tune an isotope, TTL or shedding model to absorb anchor residuals.

## Evidence boundary

The present data can falsify a constant transferred gain and diagnose count-window effects. They cannot establish kappa, the validity of its proposed observation law, a physical stability level, or SI traceability. Software checks passing means the stated diagnostics execute correctly; rejected hypotheses remain rejected.
