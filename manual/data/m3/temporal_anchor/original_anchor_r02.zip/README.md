# Temporal anchor validation — R02

Executed 2026-11-03. Detached audit of the prior closure/Cs/SI bridge; original dynamics, histories, reference fields and historical records are preserved.

**The SI anchor is not established. The existing finite run rejects a fixed transferred gain for A and B, and its two nominal reference fields have identical closure timings.**

## What the earlier percentages mean

The earlier −1/54 (−1.85%) and −9/62 (−14.52%) are exactly reproduced. They measure discrepancies caused by reusing a count-transfer coefficient from another coupling condition or window. They are not measured Cs frequency errors, statistical uncertainties, or a precision limit of the SI second.

The R01 identity g_A(ω) = κ N_R(ω)/N_A(ω) implies g_A(ω) N_A(ω) = κ N_R(ω) by construction for every positive count pair. It is a valid descriptive conversion under the declared law. Its zero route residual does not independently validate the law C_Cs(ω) = κ N_R(ω), because there is no separately measured C_Cs in these records.

## A frozen transfer tested on a separate window

Each existing run is divided into calibration (300000,1808096] and validation (1808096,3316192]. Both halves contain 32 F0 reclosures. Fit g = N_F0,cal / N_i,cal using the first half only, freeze it, and predict N_F0,val from the second half’s N_i,val. The comparison target does not enter the prediction function.

| Scenario | Field | Calibration closures | Validation closures | Frozen F0 bips / closure | Predicted validation F0 bips | Residual versus 32 F0 bips |
|---|---|---:|---:|---|---|---|
| Shared background | A | 59 | 49 | 32/59 | 1568/59 | -16.95% (-10/59) |
| Shared background | B | 188 | 121 | 8/47 | 968/47 | -35.64% (-67/188) |
| Shared background | F1 | 32 | 32 | 1 | 32 | 0.00% (0) |
| Direct A/B coupling | A | 58 | 48 | 16/29 | 768/29 | -17.24% (-5/29) |
| Direct A/B coupling | B | 151 | 102 | 32/151 | 3264/151 | -32.45% (-49/151) |
| Direct A/B coupling | F1 | 32 | 32 | 1 | 32 | 0.00% (0) |
| Contacts recorded; feedback disabled | A | 59 | 49 | 32/59 | 1568/59 | -16.95% (-10/59) |
| Contacts recorded; feedback disabled | B | 188 | 121 | 8/47 | 968/47 | -35.64% (-67/188) |
| Contacts recorded; feedback disabled | F1 | 32 | 32 | 1 | 32 | 0.00% (0) |

For the coupled case, A changes from 58 to 48 closures and B from 151 to 102 over equal F0-bip increments. Reusing a first-half gain consequently yields −17.24% and −32.45% count-transfer residuals. That rejects this fixed-gain specialization; it does not reject relational time or measure the accuracy of a Cs clock. The shared-background case also evolves, so the drift cannot all be attributed to enabling the direct A/B link.

This split is retrospective and shares a continuous dynamical history. It prevents validation-target fitting in the calculation; it is not an independent laboratory experiment or a prospective prediction.

## Endpoint counting does not explain all the evolution

At all 64 retained F0 closure endpoints, test whether cumulative field counts admit y_j = floor(α x_j + β) for one fixed α > 0 and one count origin β. This explicitly allows whole-count rounding. The pairwise necessary and sufficient inequalities are

\[\frac{y_j-y_i-1}{x_j-x_i}<\alpha<\frac{y_j-y_i+1}{x_j-x_i}\qquad(i<j).\]

All are tested with rational arithmetic. For the coupled run:

| Field | Required lower bound on α | Required upper bound on α | Constant-cadence rounding model |
|---|---|---|---|
| A | α > 23/12 | α < 3/2 | Impossible |
| B | α > 6 | α < 3 | Impossible |
| F1 | α > 62/63 | α < 64/63 | Compatible |

For A, early samples require α > 23/12 while later samples require α < 3/2. For B the corresponding requirements include α > 6 and α < 3. Thus an unknown count origin and integer rounding cannot make either complete series have one constant cadence. This rejects the specified rounding null; it does not rule out every possible jitter or observation model.

The audit also covers 588 rolling count windows (4, 8, 16 and 32 reference bips) and 216 endpoint perturbation cases. Those projections retain exact event-count bounds. They overlap and provide descriptive diagnostics, not independent samples or a standard uncertainty. Six half windows receive full temporal admission, with three directional comparisons each.

![Cadence evolution](cadence_validation.png)

## The reference check is degenerate for independent validation

F0 and F1 are distinct admitted 3:4:6 lineages, but their reclosure endpoint sequences are identical in all three retained scenarios. The reference sequence within the comparison window is also unchanged across these scenarios. Their zero discrepancy therefore gives no independent evidence of a physical anchor or robustness to perturbing the reference itself. The original construction uses symmetric reference specifications; this audit does not introduce an asymmetric perturbation or a replacement dynamics.

Both 3:4:6 fields, all operative coupling histories, directional RCD and lag records remain in the preserved input. Reference identity, current population and coupling state remain part of the proposed calibration domain. A generic F0 field is not identified with a Cs atom.

## What can now be accepted

| Claim | Disposition |
|---|---|
| Prior transfer discrepancies and descriptive window ratios | Reproduced exactly |
| One fixed A/B-to-F0 gain transfers across these half windows | Rejected |
| A/B cadence variation is only constant-cadence whole-count rounding | Rejected for the stated null |
| F0/F1 equality supplies independent reference validation | Unsupported: identical endpoint histories |
| Same-window symbolic conversion is internally consistent | Conditional algebra; retained |
| Physical C_Cs = κ N_R observation law and calibrated κ | Not established |
| Numerical physical seconds, hertz and uncertainty | Not identified |

The next empirical gate is a bound observation map plus synchronized Cs-referenced oscillator phase/cycle records and model reference closure events. Calibrate on a declared subset, freeze the scale and its domain, then compare separate windows and coupling conditions against measured cycles with justified uncertainty and covariance. The requirement is compatibility with a predeclared metrological tolerance, not a residual forced to zero. VALIDATION_PROTOCOL.md gives the concrete record and acceptance requirements.

SOURCES.md distinguishes the exact SI definition from practical realization and clock stability analysis. Neither the defining number nor the present finite simulation supplies the missing observation calibration. No isotope, TTL or shedding parameter was adjusted.

## Reproducibility

33 audit checks pass in normal and optimized Python. All 5 output files are byte-identical. The inherited bridge, pair simulation, source bytes and owner plan are bound in INPUT_BINDING.json; the historical bridge is retained under baseline/.

```bash
PYTHONDONTWRITEBYTECODE=1 python3 audit_anchor.py
PYTHONDONTWRITEBYTECODE=1 python3 -O audit_anchor.py --output ../results-optimized
PYTHONDONTWRITEBYTECODE=1 python3 build_report.py --optimized ../results-optimized
```

Python 3.12 and its standard library run the audit. Matplotlib renders the figure. tests.txt records software validation, including the intended rejection of scientific null hypotheses. No repository manuscript or engine was changed, so this audit makes no claim of a new Main/Manual build or current hosted PR validation.
