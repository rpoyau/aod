#!/usr/bin/env python3
"""Run exact window, reference-transfer and scale-identifiability tests."""
import argparse
from copy import deepcopy
from fractions import Fraction as Q
import json
from pathlib import Path
import si_bridge as s


def write(path,value):
    path.write_text(json.dumps(s.p.plain(value),indent=2,sort_keys=True)+'\n')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=s.HERE/'results')
    args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    s.verify_inputs()
    frozen={'contract_sha256':s.p.digest(json.loads((s.HERE/'OBSERVATION_CONTRACT.json').read_text())),
            'code_sha256':{name:s.sha(s.HERE/name) for name in ('si_bridge.py','run_bridge_tests.py')}}
    write(args.output/'frozen_contract.json',frozen)
    all_records={};checks=[];datasets={}
    def check(name,condition):
        s.p.require(condition,'check failed: '+name);checks.append({'name':name,'status':'pass'})
    def reject(name,fn):
        try:fn()
        except (ValueError,TypeError) as e:checks.append({'name':name,'status':'pass','rejection':str(e)})
        else:raise ValueError('invalid case accepted: '+name)

    for scenario in ('background_only','direct_pair','recorded_only'):
        data=s.load_scenario(scenario);datasets[scenario]=data
        lo,hi=data['summary']['window'];step=(hi-lo)//4
        windows={f'prefix_{k}':[lo,lo+k*step] for k in (1,2,3,4)}
        windows.update({f'quarter_{k}':[lo+(k-1)*step,lo+k*step] for k in (2,3,4)})
        records={}
        for name,window in windows.items():
            records[name]=s.predict(data,window)
            ctx,mapped=records[name]['context'],records[name]['mapped']
            counts=ctx['record']['counts'];g=mapped['gain_coefficient_multiplying_kappa']
            check(scenario+'/'+name+': A B F0 reference routes agree',Q(g['A'])*counts['A']==Q(g['B'])*counts['B']==counts['F0'])
            check(scenario+'/'+name+': SI values remain unidentified',mapped['physical_elapsed_seconds'] is None and mapped['physical_rate_hz'] is None)
        partitions=[records['prefix_1'],*[records['quarter_'+str(k)] for k in (2,3,4)]]
        full=records['prefix_4']
        check(scenario+': mapped interval coefficients add over adjacent windows',
              sum(Q(x['mapped']['elapsed_seconds_coefficient_multiplying_kappa']) for x in partitions)==Q(full['mapped']['elapsed_seconds_coefficient_multiplying_kappa']))
        check(scenario+': closure counts add with committed endpoint convention',
              all(sum(x['context']['record']['counts'][name] for x in partitions)==full['context']['record']['counts'][name] for name in ('A','B','F0','F1')))
        all_records[scenario]=records
        print(json.dumps({'scenario':scenario,'status':'pass','windows':len(records),'full_counts':full['context']['record']['counts']}),flush=True)

    base=all_records['background_only']['prefix_4'];coupled=all_records['direct_pair']['prefix_4']
    ga0=Q(base['mapped']['gain_coefficient_multiplying_kappa']['A'])
    ga1=Q(coupled['mapped']['gain_coefficient_multiplying_kappa']['A'])
    ca=coupled['context']['record']['counts']['A'];cr=coupled['context']['record']['counts']['F0']
    stale_population=ga0*ca
    quarter=all_records['direct_pair']['prefix_1']
    stale_window=Q(quarter['mapped']['gain_coefficient_multiplying_kappa']['A'])*ca
    failures={'stale_baseline_gain':{'predicted_Cs_cycle_coefficient':str(stale_population),'correct_coefficient':str(cr),
                                    'relative_error':str(stale_population/cr-1)},
              'stale_short_window_gain':{'predicted_Cs_cycle_coefficient':str(stale_window),'correct_coefficient':str(cr),
                                        'relative_error':str(stale_window/cr-1)}}
    check('coupling changes derived gain without changing kappa',ga0!=ga1)
    check('stale baseline gain is a counterexample to transfer',stale_population!=cr and stale_population/cr-1==Q(-1,54))
    check('stale short-window gain is a counterexample to transfer',stale_window!=cr and stale_window/cr-1==Q(-9,62))
    countermodels=[s.hypothetical_scale(coupled['mapped'],k,classification='hypothetical_countermodel') for k in (1,2)]
    check('same closure histories permit different SI scales without calibration',
          Q(countermodels[1]['elapsed_seconds'])==2*Q(countermodels[0]['elapsed_seconds']) and
          all(2*Q(countermodels[1]['rates_hz'][name])==Q(countermodels[0]['rates_hz'][name]) for name in ('A','B')))
    reject('definition alone cannot promote hypothetical scale to physical calibration',
           lambda:s.hypothetical_scale(coupled['mapped'],1,classification='physical_calibration'))
    reject('Boolean numerical substitute rejected',lambda:s.hypothetical_scale(coupled['mapped'],True,classification='hypothetical_countermodel'))
    reject('nonpositive cycle scale rejected',lambda:s.hypothetical_scale(coupled['mapped'],0,classification='hypothetical_countermodel'))
    original=datasets['direct_pair'];window=original['summary']['window']
    serialized=json.loads(json.dumps(coupled))
    check('genuine serialized artifact replays from original context',s.evaluate_supplied(serialized,original_data=original,original_window=window)==coupled)
    altered=deepcopy(coupled);altered['mapped']['elapsed_seconds_coefficient_multiplying_kappa']='1'
    reject('altered mapped value rejected',lambda:s.evaluate_supplied(altered,original_data=original,original_window=window))
    altered2=deepcopy(coupled);altered2['context']['record']['counts']['A']+=1
    altered2['context']['sha256']=s.p.digest(altered2['context']['record'])
    altered2['mapped']=s._symbolic_for_validated_context(altered2['context'])
    reject('altered counts with recomputed hashes rejected',lambda:s.evaluate_supplied(altered2,original_data=original,original_window=window))
    reject('substituted baseline history rejected',lambda:s.evaluate_supplied(coupled,original_data=datasets['background_only'],original_window=window))
    reject('changed observation window rejected',lambda:s.evaluate_supplied(coupled,original_data=original,original_window=quarter['context']['record']['window']))
    check('contract and code remain frozen',frozen['contract_sha256']==s.p.digest(json.loads((s.HERE/'OBSERVATION_CONTRACT.json').read_text())) and all(s.sha(s.HERE/name)==sha for name,sha in frozen['code_sha256'].items()))
    write(args.output/'window_records.json',all_records)
    write(args.output/'transfer_counterexamples.json',failures)
    write(args.output/'scale_countermodels.json',countermodels)
    report={'status':'pass','checks':checks,'check_count':len(checks),'frozen_contract':frozen,
            'window_count':sum(len(r) for r in all_records.values()),
            'calibration_status':'kappa not measured; physical SI output withheld',
            'derived_gains_full_window':{'baseline_gA_over_kappa':str(ga0),'coupled_gA_over_kappa':str(ga1)},
            'counterexamples':failures,'empirical_validation':False,
            'uniformity_scope':'Algebraic consistency of one declared observation law, not independent physical validation of that law.'}
    write(args.output/'report.json',report)
    print(json.dumps({'status':'pass','checks':len(checks),'windows':report['window_count'],'physical_calibration':False}),flush=True)


if __name__=='__main__':main()
