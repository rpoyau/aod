#!/usr/bin/env python3
"""Verify mode agreement and render the conditional SI bridge evidence."""
import argparse
from fractions import Fraction as Q
import hashlib
import json
from pathlib import Path
import platform
import si_bridge as s


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--optimized',type=Path,required=True)
    args=parser.parse_args();root=s.HERE
    a={p.name:p for p in (root/'results').iterdir() if p.is_file()}
    b={p.name:p for p in args.optimized.iterdir() if p.is_file()}
    s.p.require(a.keys()==b.keys(),'mode output sets differ')
    hashes={}
    for name in sorted(a):
        data=a[name].read_bytes();s.p.require(data==b[name].read_bytes(),'mode bytes differ: '+name)
        hashes[name]=hashlib.sha256(data).hexdigest()
    report=json.loads(a['report.json'].read_text())
    records=json.loads(a['window_records.json'].read_text())
    s.p.require(all(c['status']=='pass' for c in report['checks']),'check failed')
    s.verify_inputs()
    for name,sha in report['frozen_contract']['code_sha256'].items():
        s.p.require(s.sha(root/name)==sha,'frozen code changed')
    s.p.require(s.p.digest(json.loads((root/'OBSERVATION_CONTRACT.json').read_text()))==report['frozen_contract']['contract_sha256'],'contract changed')
    validation={'status':'pass','checks_per_mode':report['check_count'],'windows':report['window_count'],
                'modes':['normal','optimized (-O)'],'python':platform.python_version(),
                'byte_identical_records':len(hashes),'sha256':hashes,
                'physical_calibration':False,'physical_seconds_identified':False,
                'input_and_frozen_code_unchanged':True}
    (root/'validation.json').write_text(json.dumps(validation,indent=2,sort_keys=True)+'\n')
    (root/'tests.txt').write_text('\n'.join([
        'PYTHONDONTWRITEBYTECODE=1 python3 run_bridge_tests.py',
        'PYTHONDONTWRITEBYTECODE=1 python3 -O run_bridge_tests.py --output ../results-optimized',
        f'PASS: {report["check_count"]} checks in each mode; {report["window_count"]} scenario/window records',
        f'PASS: {len(hashes)} result files byte-identical',
        *[x['status'].upper()+': '+x['name'] for x in report['checks']],
        'PHYSICAL CALIBRATION: not established; numerical physical SI output remains null','']))

    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,
                         'axes.spines.right':False,'axes.grid':True,'grid.alpha':.18})
    fig,axes=plt.subplots(1,2,figsize=(13,5.1))
    fig.subplots_adjust(left=.08,right=.98,bottom=.22,top=.79,wspace=.80)
    fig.suptitle('A fixed reference scale with a window-specific transfer',fontsize=16,fontweight='bold',y=.97)
    x=[.25,.5,.75,1]
    for scenario,label,color in [('background_only','Shared background only','#667580'),('direct_pair','Direct 3:3:6 ↔ 1:2:6 coupling','#087F8C')]:
        y=[float(Q(records[scenario]['prefix_'+str(k)]['mapped']['gain_coefficient_multiplying_kappa']['A'])) for k in (1,2,3,4)]
        axes[0].plot(x,y,'o-',color=color,label=label)
    axes[0].set(xlabel='Fraction of the full comparison window',ylabel='Derived transfer coefficient g_A / κ',xticks=x)
    axes[0].legend(fontsize=8.5,loc='upper left')
    errors=[0,100*float(Q(-1,54)),100*float(Q(-9,62))]
    axes[1].barh([0,1,2],errors,color=['#087F8C','#A75A32','#A75A32'],height=.55)
    axes[1].scatter([0],[0],color='#087F8C',s=50,zorder=4)
    axes[1].set(yticks=[0,1,2],yticklabels=['Window-aware transfer','Reuse baseline gain','Reuse quarter-window gain'],xlabel='Conditional cycle-increment error (%)',xlim=(-17,1))
    axes[1].invert_yaxis()
    axes[1].tick_params(axis='y',labelsize=9)
    for i,value in enumerate(errors):
        inside=value<-5
        axes[1].annotate(f'{value:.2f}%',(0 if inside else value,i),xytext=(-6,-3),textcoords='offset points',ha='right',fontsize=9,color='white' if inside else '#24343E')
    fig.text(.5,.04,'Exact finite-model comparisons · κ remains unmeasured · No physical seconds or hertz are asserted',ha='center',fontsize=9,color='#526475')
    fig.savefig(root/'window_transfer.png',dpi=170)
    fig.savefig(root/'window_transfer.pdf',metadata={'CreationDate':None,'ModDate':None})
    plt.close(fig)

    base=records['background_only']['prefix_4'];coupled=records['direct_pair']['prefix_4']
    body=['# Closure → Cs-cycle → second bridge',
          '', 'Executed 2026-11-03 as a detached extension of the sealed 3:3:6 / 1:2:6 coupling trial.',
          '', '**The conditional mapping is implemented and tested. Its window-dependent transfer follows the actual field-to-field closure counts. The physical Cs calibration scale remains unidentified.**',
          '', '## Exact construction',
          '', 'Let R be the already admitted F0 background field, A the 3:3:6 field and B the 1:2:6 field. All counts use the same committed window. Keep each field identity, population, directional RCD, phase, lag and endpoint prefix in the input record.',
          '', 'The proposed observation law is C_Cs(ω) = κ N_R(ω), where C_Cs is the corrected Cs-referenced microwave-cycle increment. κ is a positive, externally calibrated cycles-per-reference-bip scale. The law is conditional and scoped to the declared reference realization; F0 is not identified with a Cs atom.',
          '', 'With ν_Cs = 9,192,631,770 Hz,',
          '', r'\[g_A(\omega)=\kappa\frac{N_R(\omega)}{N_A(\omega)},\qquad',
          r'\Delta t(\omega)=\frac{\kappa N_R(\omega)}{\nu_{\mathrm{Cs}}},\qquad',
          r'\overline f_B(\omega)=\frac{\nu_{\mathrm{Cs}}N_B(\omega)}{\kappa N_R(\omega)}.\]',
          '', 'One frozen κ is used symbolically. The factor g_A changes because the admitted reference-to-A cadence changes. No per-window fit to a desired seconds value is performed.',
          '', '| Full-window case | N_A | N_B | N_R | g_A / κ | Elapsed interval |',
          '|---|---:|---:|---:|---|---|']
    for name,label in [('background_only','Shared background'),('direct_pair','Direct A/B coupling'),('recorded_only','Direct contacts with feedback disabled')]:
        row=records[name]['prefix_4'];c=row['context']['record']['counts'];m=row['mapped']
        body.append(f'| {label} | {c["A"]} | {c["B"]} | {c["F0"]} | {m["gain_coefficient_multiplying_kappa"]["A"]} | {c["F0"]}κ / ν_Cs |')
    body += ['', 'For the coupled full window, the mean rates are 106ν_Cs/(64κ) for A and 253ν_Cs/(64κ) for B. Their ratio remains 253/106. The unknown physical scale cancels from this relational result.',
             '', 'The three full windows have the same reference count in this finite trial. That is a result of these retained reference histories; it is not a claim that arbitrary population changes preserve the reference.',
             '', '## Window dependence',
             '', '| Coupled prefix window | N_A | N_B | N_R | g_A / κ |',
             '|---|---:|---:|---:|---|']
    for k,label in [(1,'Quarter'),(2,'Half'),(3,'Three quarters'),(4,'Full')]:
        row=records['direct_pair']['prefix_'+str(k)];c=row['context']['record']['counts']
        body.append(f'| {label} | {c["A"]} | {c["B"]} | {c["F0"]} | {row["mapped"]["gain_coefficient_multiplying_kappa"]["A"]} |')
    body += ['', '![Window-specific transfer and stale-gain controls](window_transfer.png)',
             '', 'Reusing the baseline full-window g_A on the coupled history gives 1696κ/27 cycle equivalents instead of 64κ: relative error −1/54, approximately −1.85%. Reusing the coupled quarter-window factor on the full coupled history gives 1696κ/31 instead of 64κ: relative error −9/62, approximately −14.52%. These are deterministic counterexamples inside the conditional model, not measured Cs-clock errors.',
             '', '## Uniformity checks',
             '', 'Each window is admitted again from the complete serialized wave and contact evidence. Comparisons with F0 establish the A and B routes; direct directional A/B comparisons are also retained where those channels exist. A, B and F0 routes give identical symbolic elapsed intervals under the same observation contract. Four adjacent quarter-window coefficients add exactly to the full interval. Closure counts use (u,v], and native contact admission uses [u,v]; prior histories remain present when a subwindow is selected.',
             '', 'These equalities verify algebra and provenance under the stated law. They are not independent evidence that C_Cs = κ N_R is physically correct. The two compared fields share the same reference and calibration, so no statistical independence is assumed.',
             '', '## What the hyperfine correlation still needs',
             '', 'In a Cs clock, atomic transition response supplies resonance feedback and oscillator cycles supply the interval count. This trial has AOD closure/coupling histories but no synchronized atomic-response, oscillator-phase or detector measurements. MEASUREMENT_REQUIREMENTS.json specifies the matched records, corrections, uncertainty and independent validation needed to estimate and test κ.',
             '', 'A measured correlation would bind the reference-field observation to those records, estimate κ on a declared calibration subset, freeze the observation law and then test separate windows and coupling conditions. If the constant-κ hypothesis fails within its declared reference domain, the observation law must be revised and tested; the discrepancy cannot be hidden in a fresh application gain.',
             '', 'The SI defining number alone supplies no κ. With the same closure histories, hypothetical κ=1 and κ=2 yield different elapsed intervals and rates while preserving every relational cadence. Both alternatives are emitted only as explicitly labelled countermodels. All physical seconds, physical hertz and complete physical standard uncertainties remain null in the actual reports.',
             '', 'Sources and their roles are recorded in SOURCES.md. No hyperfine transition frequency, driven population frequency, photon count, detection rate or spontaneous waiting time is silently substituted for another.',
             '', '## Validation and reproducibility',
             '', f'{report["check_count"]} checks pass in normal and optimized Python over {report["window_count"]} scenario/window records. All {len(hashes)} generated output files are byte-identical. The inherited paired simulation and upstream source bytes remain unchanged.',
             '', 'Regressions cover reference-route agreement, interval partitioning, unsupported physical promotion, scale ambiguity, strict numerical typing, positive scale, genuine serialized replay, altered values, changed counts with recomputed hashes, substituted histories, changed windows and frozen bindings.',
             '', '```bash',
             'PYTHONDONTWRITEBYTECODE=1 python3 run_bridge_tests.py',
             'PYTHONDONTWRITEBYTECODE=1 python3 -O run_bridge_tests.py --output ../results-optimized',
             'PYTHONDONTWRITEBYTECODE=1 python3 build_report.py --optimized ../results-optimized',
             '```',
             '', 'The last command compares the packaged normal outputs with the optimized rerun, then regenerates this report and the figure. Python 3.12 and the standard library execute the bridge; Matplotlib renders the figure. The full paired input, including its original dynamics and evidence, is preserved under input/. tests.txt, validation.json and MANIFEST_SHA256.txt provide the completed evidence and integrity checks.',
             '']
    (root/'README.md').write_text('\n'.join(body))
    print(json.dumps(validation,sort_keys=True))


if __name__=='__main__':main()
