# Closure → Cs-cycle → second bridge

Executed 2026-11-03 as a detached extension of the sealed 3:3:6 / 1:2:6 coupling trial.

**The conditional mapping is implemented and tested. Its window-dependent transfer follows the actual field-to-field closure counts. The physical Cs calibration scale remains unidentified.**

## Exact construction

Let R be the already admitted F0 background field, A the 3:3:6 field and B the 1:2:6 field. All counts use the same committed window. Keep each field identity, population, directional RCD, phase, lag and endpoint prefix in the input record.

The proposed observation law is C_Cs(ω) = κ N_R(ω), where C_Cs is the corrected Cs-referenced microwave-cycle increment. κ is a positive, externally calibrated cycles-per-reference-bip scale. The law is conditional and scoped to the declared reference realization; F0 is not identified with a Cs atom.

With ν_Cs = 9,192,631,770 Hz,

\[g_A(\omega)=\kappa\frac{N_R(\omega)}{N_A(\omega)},\qquad
\Delta t(\omega)=\frac{\kappa N_R(\omega)}{\nu_{\mathrm{Cs}}},\qquad
\overline f_B(\omega)=\frac{\nu_{\mathrm{Cs}}N_B(\omega)}{\kappa N_R(\omega)}.\]

One frozen κ is used symbolically. The factor g_A changes because the admitted reference-to-A cadence changes. No per-window fit to a desired seconds value is performed.

| Full-window case | N_A | N_B | N_R | g_A / κ | Elapsed interval |
|---|---:|---:|---:|---|---|
| Shared background | 108 | 309 | 64 | 16/27 | 64κ / ν_Cs |
| Direct A/B coupling | 106 | 253 | 64 | 32/53 | 64κ / ν_Cs |
| Direct contacts with feedback disabled | 108 | 309 | 64 | 16/27 | 64κ / ν_Cs |

For the coupled full window, the mean rates are 106ν_Cs/(64κ) for A and 253ν_Cs/(64κ) for B. Their ratio remains 253/106. The unknown physical scale cancels from this relational result.

The three full windows have the same reference count in this finite trial. That is a result of these retained reference histories; it is not a claim that arbitrary population changes preserve the reference.

## Window dependence

| Coupled prefix window | N_A | N_B | N_R | g_A / κ |
|---|---:|---:|---:|---|
| Quarter | 31 | 88 | 16 | 16/31 |
| Half | 58 | 151 | 32 | 16/29 |
| Three quarters | 83 | 205 | 48 | 48/83 |
| Full | 106 | 253 | 64 | 32/53 |

![Window-specific transfer and stale-gain controls](window_transfer.png)

Reusing the baseline full-window g_A on the coupled history gives 1696κ/27 cycle equivalents instead of 64κ: relative error −1/54, approximately −1.85%. Reusing the coupled quarter-window factor on the full coupled history gives 1696κ/31 instead of 64κ: relative error −9/62, approximately −14.52%. These are deterministic counterexamples inside the conditional model, not measured Cs-clock errors.

## Uniformity checks

Each window is admitted again from the complete serialized wave and contact evidence. Comparisons with F0 establish the A and B routes; direct directional A/B comparisons are also retained where those channels exist. A, B and F0 routes give identical symbolic elapsed intervals under the same observation contract. Four adjacent quarter-window coefficients add exactly to the full interval. Closure counts use (u,v], and native contact admission uses [u,v]; prior histories remain present when a subwindow is selected.

These equalities verify algebra and provenance under the stated law. They are not independent evidence that C_Cs = κ N_R is physically correct. The two compared fields share the same reference and calibration, so no statistical independence is assumed.

## What the hyperfine correlation still needs

In a Cs clock, atomic transition response supplies resonance feedback and oscillator cycles supply the interval count. This trial has AOD closure/coupling histories but no synchronized atomic-response, oscillator-phase or detector measurements. MEASUREMENT_REQUIREMENTS.json specifies the matched records, corrections, uncertainty and independent validation needed to estimate and test κ.

A measured correlation would bind the reference-field observation to those records, estimate κ on a declared calibration subset, freeze the observation law and then test separate windows and coupling conditions. If the constant-κ hypothesis fails within its declared reference domain, the observation law must be revised and tested; the discrepancy cannot be hidden in a fresh application gain.

The SI defining number alone supplies no κ. With the same closure histories, hypothetical κ=1 and κ=2 yield different elapsed intervals and rates while preserving every relational cadence. Both alternatives are emitted only as explicitly labelled countermodels. All physical seconds, physical hertz and complete physical standard uncertainties remain null in the actual reports.

Sources and their roles are recorded in SOURCES.md. No hyperfine transition frequency, driven population frequency, photon count, detection rate or spontaneous waiting time is silently substituted for another.

## Validation and reproducibility

61 checks pass in normal and optimized Python over 21 scenario/window records. All 5 generated output files are byte-identical. The inherited paired simulation and upstream source bytes remain unchanged.

Regressions cover reference-route agreement, interval partitioning, unsupported physical promotion, scale ambiguity, strict numerical typing, positive scale, genuine serialized replay, altered values, changed counts with recomputed hashes, substituted histories, changed windows and frozen bindings.

```bash
PYTHONDONTWRITEBYTECODE=1 python3 run_bridge_tests.py
PYTHONDONTWRITEBYTECODE=1 python3 -O run_bridge_tests.py --output ../results-optimized
PYTHONDONTWRITEBYTECODE=1 python3 build_report.py --optimized ../results-optimized
```

The last command compares the packaged normal outputs with the optimized rerun, then regenerates this report and the figure. Python 3.12 and the standard library execute the bridge; Matplotlib renders the figure. The full paired input, including its original dynamics and evidence, is preserved under input/. tests.txt, validation.json and MANIFEST_SHA256.txt provide the completed evidence and integrity checks.
