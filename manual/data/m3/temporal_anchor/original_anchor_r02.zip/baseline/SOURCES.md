# Source and observation binding

The input is the executed `AOD_336_126_Closure_Per_Bip_R01_2026-11-03.zip`, preserved under `input/` and bound file by file in `INPUT_BINDING.json`. Its original source commit is `3ffb3c9984eef95ca4b105ac323d249f30412816` in `rpoyau/aod`. Its declared population dynamics and all historical qualifications remain unchanged.

The attached `AOD_M1_CLOSURE_WAVE_RELATIONAL_TIME_SINGLE_PLAN.md`, §3.11, separates closure/coupling records from a calibrated measurement record and requires the observation protocol, reference, detector, calibration, units, resolution, uncertainty, repeatability and traceability.

The current [Matter I folding and hyperfine plan](https://chatgpt.com/library?file_id=libfile_5207a7925b4c8191b9a4aab061fec9e3&account_id=personal), version 2, was read on 2026-11-03. Its §7 distinguishes resonance-frequency comparison, transition-population detection and oscillator-cycle counting. It calls for a separately bound atomic observation map and frozen calibration before validation. Its historical repository head does not supersede the simulation source binding above.

The [BIPM second definition](https://www.bipm.org/en/si-base-units/second), accessed 2026-11-03, fixes the unperturbed Cs-133 ground-state hyperfine transition frequency at 9,192,631,770 Hz. This supplies the exact unit conversion once an applicable reference-cycle observation has been established. It does not determine the number of those cycles corresponding to an AOD reference-field bip.

[NIST's beam-clock explanation](https://www.nist.gov/atomic-clocks/how-atomic-clocks-work/beams-atoms-first-atomic-clocks), accessed 2026-11-03, describes microwave interrogation of cesium, atomic-state detection used to tune the microwave frequency, and counting the tuned microwave cycles. The transition-response record and oscillator-cycle record have different roles. That operational correspondence motivates the proposed observation contract here; it supplies no measured calibration for the simulated F0 field.

No laboratory counter sequence or detector record synchronized with the supplied simulated closure histories was supplied or found in the inspected project material. The inspected references establish the measurement mechanism and required record types. They do not establish the proposed constant-kappa observation law for this simulation.
