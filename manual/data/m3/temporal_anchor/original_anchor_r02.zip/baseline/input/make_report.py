#!/usr/bin/env python3
"""Check optimized replay and render the direct-pair results."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import platform

import population as p


def unpack(path):
    return json.loads(gzip.decompress(path.read_bytes()))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--optimized',type=Path,required=True)
    args=parser.parse_args()
    root=p.HERE;out=root/'results'
    normal={x.name:x for x in out.iterdir() if x.is_file()}
    other={x.name:x for x in args.optimized.iterdir() if x.is_file()}
    p.require(normal.keys()==other.keys(),'normal/optimized output sets differ')
    hashes={}
    for name in sorted(normal):
        data=normal[name].read_bytes()
        p.require(data==other[name].read_bytes(),'normal/optimized bytes differ: '+name)
        hashes[name]=hashlib.sha256(data).hexdigest()
    report=json.loads((out/'report.json').read_text())
    p.require(all(c['status']=='pass' for c in report['checks']),'one or more pair checks failed')
    p.check_sources()
    for name,sha in report['contract']['code_sha256'].items():
        p.require(hashlib.sha256((root/name).read_bytes()).hexdigest()==sha,'frozen code changed')
    p.require(report['contract']['model_sha256']==p.digest(json.loads((root/'MODEL.json').read_text())),'model changed')
    reference=json.loads((root/'common-reference.json').read_text())
    p.require((root/'common-reference.json').read_bytes()==(args.optimized.parent/'common-reference-optimized.json').read_bytes(),'common-reference optimized replay differs')
    p.require(all(row['status']=='pass' for row in reference),'common-reference comparison failed')
    validation={'status':'pass','modes':['normal','optimized (-O)'],
                'python':platform.python_version(),'checks_per_mode':report['check_count'],
                'byte_identical_record_count':len(hashes),'sha256':hashes,
                'source_commit':report['source_commit'],'frozen_model_sha256':report['contract']['model_sha256'],
                'common_reference_cases_per_mode':len(reference),
                'common_reference_sha256':hashlib.sha256((root/'common-reference.json').read_bytes()).hexdigest(),
                'scope':'Direct-pair model and admitted record checks; not the full upstream repository or publication suite.'}
    (root/'validation.json').write_text(json.dumps(validation,indent=2,sort_keys=True)+'\n')
    (root/'tests.txt').write_text('\n'.join([
        'PYTHONDONTWRITEBYTECODE=1 python3 pair_trial.py',
        'PYTHONDONTWRITEBYTECODE=1 python3 -O pair_trial.py --output ../results-optimized',
        f'PASS: {report["check_count"]} checks in each mode',
        f'PASS: {len(hashes)} generated records byte-identical',
        f'PASS: {len(reference)} common-reference cases in each mode; common-reference record byte-identical',
        'PASS: frozen model, inherited engine and copied upstream sources unchanged',
        *[c['status'].upper()+': '+c['name'] for c in report['checks']],
        '']) )

    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.ticker import MaxNLocator
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,
                         'axes.spines.top':False,'axes.spines.right':False,
                         'axes.grid':True,'grid.alpha':.17})
    colors={'background_only':'#667580','direct_pair':'#087F8C'}
    labels={'background_only':'Shared background only','direct_pair':'Direct pair coupling added'}
    lo,hi=report['window']
    histories={s:unpack(out/(s+'.histories.json.gz')) for s in colors}
    bips={s:unpack(out/(s+'.bip-windows.json.gz')) for s in colors}
    fig,axes=plt.subplots(2,2,figsize=(12.5,8.7))
    fig.subplots_adjust(left=.08,right=.98,bottom=.11,top=.87,hspace=.43,wspace=.25)
    fig.suptitle('Direct 3:3:6 ↔ 1:2:6 coupling changes both closure histories',y=.97,fontsize=16,fontweight='bold')
    for s in colors:
        cuts={name:[tr['indices'][-1] for tr in histories[s][name]['returns'][1:]
                    if lo<tr['indices'][-1]<=hi] for name in ('A','B')}
        for name,ax in [('A',axes[0,0]),('B',axes[0,1])]:
            ks=cuts[name]
            x=[0]+[(k-lo)/1e6 for k in ks]+[(hi-lo)/1e6]
            y=[0]+list(range(1,len(ks)+1))+[len(ks)]
            ax.step(x,y,where='post',color=colors[s],label=labels[s],linewidth=1.8)
        # Relational phase portrait: compare completed reclosure counts at
        # every committed A/B reclosure, without introducing an angle.
        merged={}
        for field in ('A','B'):
            for k in cuts[field]:
                merged.setdefault(k,[]).append(field)
        a,b=0,0;xx=[0];yy=[0]
        for k in sorted(merged):
            a+=merged[k].count('A');b+=merged[k].count('B');xx.append(a);yy.append(b)
        axes[1,0].plot(xx,yy,color=colors[s],linewidth=1.8,label=labels[s])
        axes[1,0].scatter([a],[b],color=colors[s],s=30,zorder=4)
        axes[1,0].annotate(f'({a}, {b})',(a,b),xytext=(-7,7 if s=='background_only' else -16),
                           textcoords='offset points',ha='right',fontsize=9,color=colors[s],
                           bbox={'facecolor':'white','edgecolor':'none','alpha':.9,'pad':1})
    axes[0,0].set(title='A: 3:3:6 reclosures',ylabel='Completed reclosures',xlabel='Ordered cuts after coupling intervention (millions)')
    axes[0,1].set(title='B: 1:2:6 reclosures',ylabel='Completed reclosures',xlabel='Ordered cuts after coupling intervention (millions)')
    for ax in axes[0]:
        ax.set_xlim(0,(hi-lo)/1e6)
    axes[0,0].legend(fontsize=8.5,loc='upper left')
    axes[1,0].set(title='Closure compared with closure',xlabel='A bips since intervention',ylabel='B closures since intervention')
    values=sorted({int(k) for s in colors for k in bips[s]['A|B']['histogram']})
    for index,s in enumerate(colors):
        hist=bips[s]['A|B']['histogram']
        axes[1,1].bar([x+(index-.5)*.32 for x in values],[hist.get(str(x),0) for x in values],
                       width=.3,color=colors[s],label=labels[s])
    axes[1,1].set(title='B closures during one complete A bip',xlabel='B closures in (previous A closure, next A closure]',ylabel='Number of A bip windows')
    axes[1,1].set_xticks(values)
    axes[1,1].yaxis.set_major_locator(MaxNLocator(integer=True))
    fig.text(.5,.018,'Declared finite response law · Two retained 3:4:6 backgrounds · Ordered cuts are not seconds',ha='center',fontsize=9,color='#526475')
    fig.savefig(root/'pair_closures.png',dpi=170)
    fig.savefig(root/'pair_closures.pdf',metadata={'CreationDate':None,'ModDate':None})
    plt.close(fig)

    r=report['results'];base=r['background_only'];coupled=r['direct_pair'];control=r['recorded_only']
    body=['# Direct 3:3:6 ↔ 1:2:6 coupling: closures per bip',
          '', 'Executed 2026-11-03. The same declared finite update law used in the previous population trial now directly couples A = 3:3:6 and B = 1:2:6. Two separately admitted 3:4:6 background fields remain present.',
          '', '**Both generated closure histories change when the direct coupling becomes operative.**',
          '', '| Case | A reclosures (3:3:6) | B reclosures (1:2:6) | B closures / A bip over the full window |',
          '|---|---:|---:|---|']
    for key,title in [('background_only','Shared background; no direct A/B channel'),('direct_pair','Direct bidirectional A/B coupling'),('recorded_only','Direct contacts recorded; their pressure feedback disabled')]:
        row=r[key];body.append(f'| {title} | {row["counts"]["A"]} | {row["counts"]["B"]} | {row["B_closures_per_A_bip"]} |')
    body += ['',f'The common observation window is ({lo}, {hi}] in ordered cuts. Each permanent background field completes {coupled["counts"]["F0"]} and {coupled["counts"]["F1"]} reclosures respectively. A and B already have indirect coupling through that background in the baseline.',
             '', 'The three runs have identical committed histories before the intervention. Core signatures, enclosure, capacities, initial states and response coefficients remain fixed. The recorded-only control reproduces the baseline history exactly, despite retaining the direct contact records.',
             '', 'Both fields also have independently replayed, admitted comparisons with the retained F0 background on this same observation window. The quotient (B/F0)/(A/F0) reproduces the reported B/A cadence, and the difference of their unwrapped lags reproduces the B-minus-A lag. This gives the baseline an explicit common-reference comparison. The directional RCD objects remain tied to their own channels; they are not replaced by a composed scalar.',
             '', '![Generated closure histories and relational counts](pair_closures.png)',
             '', '## What “closures per bip” measures',
             '', 'A distinct reclosure of a field increments its own bip count by one. The cross-field quantity counts B closures between two consecutive A reclosures, or A closures between consecutive B reclosures. No continuous angle, phase wrapping or seconds are introduced.',
             '', 'Full-window cadence is the ratio of total closure counts. For individual bips, only complete consecutive-reference intervals wholly inside the observation window are tabulated; leading and trailing partial intervals are retained separately. Their means can therefore differ slightly from the full-window ratio.',
             '', '| Case | Complete A bip windows | B closures in those windows | Mean B closures per complete A bip | Distribution: B closures → number of A windows |',
             '|---|---:|---:|---|---|']
    for key in ('background_only','direct_pair'):
        row=r[key]['bip_statistics']['A|B']
        body.append(f'| {labels[key]} | {row["complete_reference_bips"]} | {row["compared_closures_in_complete_bips"]} | {row["mean_closures_per_reference_bip"]} | '+', '.join(k+' → '+str(v) for k,v in row['histogram'].items())+' |')
    rev=coupled['bip_statistics']['B|A']
    body += ['',f'In the reverse direction, the coupled run has {rev["complete_reference_bips"]} complete B bip windows. Their A-closure distribution is '+', '.join(k+' → '+str(v)+' windows' for k,v in rev['histogram'].items())+'. Zero A closures in a short B bip is retained as a count observation; it does not supply a complete two-cadence temporal comparison in that short window.',
             '', '## Two directional RCD feedback chains',
             '', '| Incoming channel | Source RD | Latest-two reflection counts | RCD duration | Pressure before → after | First pressure commitment cut |',
             '|---|---:|---|---:|---|---:|']
    for direction,ex in report['feedback_examples'].items():
        term=next(t for t in ex['new_pressure']['terms'] if t.get('channel')==[ex['receiver'],ex['sender']])
        old=ex['previous_pressure']['pressure'] if ex['previous_pressure'] else 'absent'
        body.append(f'| {direction} | {term["rcd"]["support"]} | {term["rcd"]["reflection_counts"]} | {term["rho"]} | {old} → {ex["new_pressure"]["pressure"]} | {ex["new_pressure"]["cut"]} |')
    body += ['', 'Each chain binds actual emitted packets, returned contacts, both wave prefixes and the pressure terms used by the next scheduling decision. The first changed traversal of each field occurs after its second incoming direct contact has returned. Already committed deadlines are preserved. The full before/after pressure decompositions and subsequent events are in results/report.json.',
             '', 'RD is obtained from enumerated support and is 61 for A, 9 for B and 137 for each background field. The directional RCD projection adds the returned reflection contributions. These support counts are not fixed physical periods. A single reclosure is counted only after the complete outward–hinge–return path is certified.',
             '', '## Window dependence and memory',
             '', 'The dynamics uses the last two actually returned contacts on each directed channel. A per-bip comparison instead asks which contacts returned inside that specific bip window. Both records are retained: endpoint RCD with carry-in memory, and within-bip RCD when at least two distinct contacts are present.',
             '', f'For the coupled A-to-B direction, {rev["carry_present_but_window_RCD_absent"]} B bip windows have endpoint carry-in RCD but too few contacts to construct a within-window RCD. No missing comparison is filled by copying the carry-in value.',
             '', 'Quarter, half and full windows are extracted from the same generated history:',
             '', '| Window fraction | A reclosures | B reclosures | B closures / A bip |',
             '|---|---:|---:|---|']
    for title,row in zip(('1/4','1/2','full'),coupled['window_checks']):
        body.append(f'| {title} | {row["counts"]["A"]} | {row["counts"]["B"]} | {row["B_closures_per_A_bip"]} |')
    body += ['', 'RCD objects reconstructed over these broader windows use all selected contacts, while the operative pressure projection uses the latest two. Their scopes are explicit; durations from these different selections are not interchangeable or assumed additive.',
             '', '## Declared choices and evidence scope',
             '', 'The inherited model enumerates q^p direction words plus q shell occurrences and uses a chosen last-direction Hamming-1 realization, one hinge and a reversed branch. This chart choice does not prove a unique atomic traversal law. A returned packet uses the source support and a directional extra reflection equal to the positive part of the committed receiver-minus-sender reclosure count. Pressure sums self-support and admitted incoming durations with unit capacities and no clipping. The integer inverse-pressure sequencer uses that pressure to schedule the next traversal.',
             '', 'The supplied experiment changes the population initialization and direct channel activation only. The earlier dynamics code is copied unchanged and hash-bound. The recorded-only control deliberately changes feedback to test causality. These numerical results are consequences of this declared finite realization, not measured properties of particles or a universal law of all coupled fields.',
             '', 'Core signatures and enclosure stay fixed. No core transformation, shedding, photon detector, Cs resonance model or SI conversion is added. The previous synthetic Cs gain is not used. This experiment answers the requested relational closure comparison directly.',
             '', '## Validation and reproduction',
             '', f'All {report["check_count"]} checks pass in normal and optimized Python. The {len(hashes)} generated records are byte-identical. Checks cover actual motif/wave admission, retained background, common pre-intervention histories, changes in both fields, feedback ablation, receiver-specific causal ordering, distinct closure counts, bip partition consistency, carry-in separation, rejected substituted contact history and frozen code/model bindings.',
             '', 'Three additional common-reference replay cases pass in each mode; their full comparison record is also byte-identical.',
             '', 'The copied source commit is `'+report['source_commit']+'` in rpoyau/aod. SOURCE_BINDING.json lists the original files and hashes; PREDECESSOR_BINDING.json binds the previous simulation engine. This is a detached simulation, with no repository mutation. It is not a rerun of the full upstream test or publication suite.',
             '', 'Use separate output directories to preserve the supplied evidence:',
             '', '```bash',
             'PYTHONDONTWRITEBYTECODE=1 python3 pair_trial.py --output ../results-repeat',
             'PYTHONDONTWRITEBYTECODE=1 python3 -O pair_trial.py --output ../results-optimized',
             'PYTHONDONTWRITEBYTECODE=1 python3 common_reference.py',
             'PYTHONDONTWRITEBYTECODE=1 python3 -O common_reference.py --results ../results-optimized --output ../common-reference-optimized.json',
             'PYTHONDONTWRITEBYTECODE=1 python3 make_report.py --optimized ../results-optimized',
             '```',
             '', 'The last command compares the packaged normal results with the optimized rerun, then regenerates this report and the figures. Core runs require Python 3.12 and the standard library; figure rendering additionally uses Matplotlib.',
             '', 'The results directory contains complete event streams, admitted histories, returned-contact evidence, pressure decompositions, all per-bip records, pending returns and exact summaries. tests.txt and validation.json record completed checks. MANIFEST_SHA256.txt binds every other delivered file.',
             '']
    (root/'README.md').write_text('\n'.join(body))
    print(json.dumps({'status':'pass','checks_per_mode':report['check_count'],'identical_records':len(hashes),'counts':{k:v['counts'] for k,v in r.items()}},sort_keys=True))


if __name__=='__main__':
    main()
