# Direct 3:3:6 ↔ 1:2:6 coupling: closures per bip

Executed 2026-11-03. The same declared finite update law used in the previous population trial now directly couples A = 3:3:6 and B = 1:2:6. Two separately admitted 3:4:6 background fields remain present.

**Both generated closure histories change when the direct coupling becomes operative.**

| Case | A reclosures (3:3:6) | B reclosures (1:2:6) | B closures / A bip over the full window |
|---|---:|---:|---|
| Shared background; no direct A/B channel | 108 | 309 | 103/36 |
| Direct bidirectional A/B coupling | 106 | 253 | 253/106 |
| Direct contacts recorded; their pressure feedback disabled | 108 | 309 | 103/36 |

The common observation window is (300000, 3316192] in ordered cuts. Each permanent background field completes 64 and 64 reclosures respectively. A and B already have indirect coupling through that background in the baseline.

The three runs have identical committed histories before the intervention. Core signatures, enclosure, capacities, initial states and response coefficients remain fixed. The recorded-only control reproduces the baseline history exactly, despite retaining the direct contact records.

Both fields also have independently replayed, admitted comparisons with the retained F0 background on this same observation window. The quotient (B/F0)/(A/F0) reproduces the reported B/A cadence, and the difference of their unwrapped lags reproduces the B-minus-A lag. This gives the baseline an explicit common-reference comparison. The directional RCD objects remain tied to their own channels; they are not replaced by a composed scalar.

![Generated closure histories and relational counts](pair_closures.png)

## What “closures per bip” measures

A distinct reclosure of a field increments its own bip count by one. The cross-field quantity counts B closures between two consecutive A reclosures, or A closures between consecutive B reclosures. No continuous angle, phase wrapping or seconds are introduced.

Full-window cadence is the ratio of total closure counts. For individual bips, only complete consecutive-reference intervals wholly inside the observation window are tabulated; leading and trailing partial intervals are retained separately. Their means can therefore differ slightly from the full-window ratio.

| Case | Complete A bip windows | B closures in those windows | Mean B closures per complete A bip | Distribution: B closures → number of A windows |
|---|---:|---:|---|---|
| Shared background only | 107 | 304 | 304/107 | 2 → 31, 3 → 62, 4 → 14 |
| Direct pair coupling added | 105 | 248 | 248/105 | 2 → 68, 3 → 36, 4 → 1 |

In the reverse direction, the coupled run has 252 complete B bip windows. Their A-closure distribution is 0 → 146 windows, 1 → 106 windows. Zero A closures in a short B bip is retained as a count observation; it does not supply a complete two-cadence temporal comparison in that short window.

## Two directional RCD feedback chains

| Incoming channel | Source RD | Latest-two reflection counts | RCD duration | Pressure before → after | First pressure commitment cut |
|---|---:|---|---:|---|---:|
| A->B | 61 | [73, 76] | 210 | 599 → 809 | 342065 |
| B->A | 9 | [0, 0] | 9 | 361 → 370 | 308359 |

Each chain binds actual emitted packets, returned contacts, both wave prefixes and the pressure terms used by the next scheduling decision. The first changed traversal of each field occurs after its second incoming direct contact has returned. Already committed deadlines are preserved. The full before/after pressure decompositions and subsequent events are in results/report.json.

RD is obtained from enumerated support and is 61 for A, 9 for B and 137 for each background field. The directional RCD projection adds the returned reflection contributions. These support counts are not fixed physical periods. A single reclosure is counted only after the complete outward–hinge–return path is certified.

## Window dependence and memory

The dynamics uses the last two actually returned contacts on each directed channel. A per-bip comparison instead asks which contacts returned inside that specific bip window. Both records are retained: endpoint RCD with carry-in memory, and within-bip RCD when at least two distinct contacts are present.

For the coupled A-to-B direction, 245 B bip windows have endpoint carry-in RCD but too few contacts to construct a within-window RCD. No missing comparison is filled by copying the carry-in value.

Quarter, half and full windows are extracted from the same generated history:

| Window fraction | A reclosures | B reclosures | B closures / A bip |
|---|---:|---:|---|
| 1/4 | 31 | 88 | 88/31 |
| 1/2 | 58 | 151 | 151/58 |
| full | 106 | 253 | 253/106 |

RCD objects reconstructed over these broader windows use all selected contacts, while the operative pressure projection uses the latest two. Their scopes are explicit; durations from these different selections are not interchangeable or assumed additive.

## Declared choices and evidence scope

The inherited model enumerates q^p direction words plus q shell occurrences and uses a chosen last-direction Hamming-1 realization, one hinge and a reversed branch. This chart choice does not prove a unique atomic traversal law. A returned packet uses the source support and a directional extra reflection equal to the positive part of the committed receiver-minus-sender reclosure count. Pressure sums self-support and admitted incoming durations with unit capacities and no clipping. The integer inverse-pressure sequencer uses that pressure to schedule the next traversal.

The supplied experiment changes the population initialization and direct channel activation only. The earlier dynamics code is copied unchanged and hash-bound. The recorded-only control deliberately changes feedback to test causality. These numerical results are consequences of this declared finite realization, not measured properties of particles or a universal law of all coupled fields.

Core signatures and enclosure stay fixed. No core transformation, shedding, photon detector, Cs resonance model or SI conversion is added. The previous synthetic Cs gain is not used. This experiment answers the requested relational closure comparison directly.

## Validation and reproduction

All 20 checks pass in normal and optimized Python. The 23 generated records are byte-identical. Checks cover actual motif/wave admission, retained background, common pre-intervention histories, changes in both fields, feedback ablation, receiver-specific causal ordering, distinct closure counts, bip partition consistency, carry-in separation, rejected substituted contact history and frozen code/model bindings.

Three additional common-reference replay cases pass in each mode; their full comparison record is also byte-identical.

The copied source commit is `3ffb3c9984eef95ca4b105ac323d249f30412816` in rpoyau/aod. SOURCE_BINDING.json lists the original files and hashes; PREDECESSOR_BINDING.json binds the previous simulation engine. This is a detached simulation, with no repository mutation. It is not a rerun of the full upstream test or publication suite.

Use separate output directories to preserve the supplied evidence:

```bash
PYTHONDONTWRITEBYTECODE=1 python3 pair_trial.py --output ../results-repeat
PYTHONDONTWRITEBYTECODE=1 python3 -O pair_trial.py --output ../results-optimized
PYTHONDONTWRITEBYTECODE=1 python3 common_reference.py
PYTHONDONTWRITEBYTECODE=1 python3 -O common_reference.py --results ../results-optimized --output ../common-reference-optimized.json
PYTHONDONTWRITEBYTECODE=1 python3 make_report.py --optimized ../results-optimized
```

The last command compares the packaged normal results with the optimized rerun, then regenerates this report and the figures. Core runs require Python 3.12 and the standard library; figure rendering additionally uses Matplotlib.

The results directory contains complete event streams, admitted histories, returned-contact evidence, pressure decompositions, all per-bip records, pending returns and exact summaries. tests.txt and validation.json record completed checks. MANIFEST_SHA256.txt binds every other delivered file.
