# Sources and evidence roles

The exact execution input is the prior `AOD_Closure_Cs_SI_Bridge_R01_2026-11-03.zip`, Library ID `libfile_e757c4c7b2d48191a6fb11c6c9ed05fe`, archive SHA-256 `e52e0178064c2280cc3cedec8510129052304b76e41e96a6598a1b5986d80e07`. Its complete delivery is retained under `baseline/`. Input file hashes are recorded in `INPUT_BINDING.json` and verified by both audit modes. The unchanged underlying source commit is `3ffb3c9984eef95ca4b105ac323d249f30412816`; this is a simulation binding, not a claim to have reviewed a newer repository head.

The current attached owner plan, `AOD_M1_CLOSURE_WAVE_RELATIONAL_TIME_SINGLE_PLAN.md`, is copied unchanged as `OWNER_PLAN.md`. Sections 3.10–3.11 require distinct recurrent lineages, common windows, actual repeated contacts, directional RCD and positive recurrence, and separately require a metrology protocol, reference, detector, calibration, unit, resolution, uncertainty and traceability.

The [BIPM definition of the second](https://www.bipm.org/en/si-base-units/second), checked 2026-11-03, sets the unperturbed Cs-133 ground-state hyperfine frequency to exactly 9,192,631,770 Hz. It fixes the unit conversion; it does not identify the simulated reference field or calibrate its bips.

[CGPM Resolution 5 (1987)](https://www.bipm.org/en/committees/cg/cgpm/18-1987/resolution-5), checked 2026-11-03, explains that realizing the unperturbed reference requires corrections for atomic motion and interactions, with experimental evaluation of the corrections and their uncertainties. This supports treating physical realization separately from an exact count identity.

William J. Riley, [NIST SP 1065, Handbook of Frequency Stability Analysis](https://www.nist.gov/publications/handbook-frequency-stability-analysis), [full handbook](https://nvlpubs.nist.gov/nistpubs/Legacy/SP/nistspecialpublication1065.pdf), especially §§1–2, checked 2026-11-03. Its framework distinguishes deterministic drift, measurement effects, reference contributions and statistical instability. Physical phase/frequency stability statistics require appropriately sampled measurement records. The present audit therefore reports count-domain diagnostics, with no claimed Allan deviation in seconds or laboratory accuracy level.

The fixed-transfer split, exact floor-affine feasibility test and endpoint perturbation calculations are declared diagnostics constructed for this audit. Their mathematical witnesses are in the generated records. They are not imported laws of AOD dynamics or empirical evidence for the Cs observation hypothesis.
