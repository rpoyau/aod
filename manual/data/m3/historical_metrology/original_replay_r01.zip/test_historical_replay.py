#!/usr/bin/env python3
"""Detached original-law replay, provenance and hostile controls.

Run: python3 test_historical_replay.py; python3 -O test_historical_replay.py
Uses only the Python standard library. Preserved source files are never edited.
Normalized coordinates are T/s, d/s and F/Hz from the original synthetic model.
No physical device uncertainty, ontology or atomic prediction is certified.
"""
import ast
from contextlib import redirect_stdout
from copy import deepcopy
from decimal import Decimal, localcontext
from fractions import Fraction as Q
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import zipfile

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
PROBE = ROOT / 'provenance/probe_metrology_edges.py'
PROBE_HASH = '685f4b2b077d2cde88f2e275800e088d156ed006aa82b648608743d3b670582e'
M3_HASH = 'b1d414e32819d3a601834883e112634bdffd7df82d742de9ede5580c96e620fc'
M3_PATH = ROOT / 'source/manual/scripts/aod_mapping_error.py'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def bind(path, expected):
    require(sha(path) == expected, 'source bytes differ')


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def literal_q(node):
    require(isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
            and node.func.id == 'Q' and not node.keywords, 'source rational assignment')
    require(all(isinstance(n, ast.Constant) and type(n.value) is int for n in node.args),
            'source rational operands')
    return Q(*(n.value for n in node.args))


def parameters_from_original():
    """Read the three rational constants from the authenticated original AST."""
    bind(PROBE, PROBE_HASH)
    main = next(n for n in ast.parse(PROBE.read_text()).body
                if isinstance(n, ast.FunctionDef) and n.name == 'main')
    values = {}
    for node in main.body:
        if not isinstance(node, ast.Assign) or len(node.targets) != 1:
            continue
        target = node.targets[0]
        if isinstance(target, ast.Name) and target.id == 'a':
            values['a'] = literal_q(node.value)
        if isinstance(target, ast.Tuple) and [n.id for n in target.elts] == ['eps', 'delta']:
            values.update(zip(['eps', 'delta'], map(literal_q, node.value.elts)))
    require(set(values) == {'a', 'eps', 'delta'}, 'original parameter assignments absent')
    return values


PARAMS = parameters_from_original()
bind(M3_PATH, M3_HASH)
m = load_module('pinned_mapping_review', M3_PATH)
INTERVAL_EXPR = ['add', ['div', ['parameter', 'one'],
                  ['add', ['parameter', 'one'], ['input', 'y']]], ['input', 'd']]
PRODUCT_EXPR = ['mul', ['input', 'ratio'], ['input', 'frequency']]


def fixture(name):
    if name == 'MAP-21':
        a = PARAMS['a']
        return {'expr': INTERVAL_EXPR, 'order': ['y', 'd'], 'parameters': {'one': {'value': '1'}},
                'support': [('1/2', {'y': str(x), 'd': str(x)}) for x in [-a, a]]}
    require(name == 'MAP-22', 'unknown criterion')
    eps, delta = PARAMS['eps'], PARAMS['delta']
    return {'expr': PRODUCT_EXPR, 'order': ['ratio', 'frequency'], 'parameters': {},
            'support': [(str(p), {'ratio': str(1+x), 'frequency': str(1-(1-delta)*x)})
                        for x, p in zip([-eps, Q(0), eps], [Q(1,4), Q(1,2), Q(1,4)])]}


def closed_form(name):
    """Independent algebraic formulas, without the expression evaluator."""
    if name == 'MAP-21':
        a = PARAMS['a']
        return Q(1)/(1-a*a), a**6/(1-a*a)**2, Q(0)
    eps, delta = PARAMS['eps'], PARAMS['delta']
    b = 1-delta
    linear = delta**2*eps**2/2
    return 1-b*eps**2/2, linear+b*b*eps**4/4, linear


def certify(name, supplied_fixture, result):
    """Certificate for the original finite law, not arbitrary equivalent output numbers."""
    require(supplied_fixture == fixture(name), 'historical joint law changed')
    mean, variance, linear = closed_form(name)
    expected = {'nominal': '1', 'output_mean': str(mean), 'output_variance': str(variance),
                'linearized_variance_diagnostic': str(linear), 'mean_shift': str(mean-1),
                'uncertainty_status': 'exact_for_declared_joint_law'}
    for key, value in expected.items():
        require(result.get(key) == value, 'historical result differs: '+key)
    return True


def run(name):
    f = fixture(name)
    result = m.propagate(**f)
    certify(name, f, result)
    return result


class HistoricalReplay(unittest.TestCase):
    def test_01_original_bytes_in_all_three_archives(self):
        members = [
          ('AOD_MATTER_I_V2_EXECUTION_REVIEW_R01_2026-10-26.zip', 'probe_metrology_edges.py'),
          ('AOD_M3_CELL_MEASURES_MAPPING_ERROR_PLAN_R01_2026-10-26.zip', 'reference/probe_metrology_edges.py'),
          ('AOD_MATTER_I_M3_REVIEW_EVIDENCE_R01_2026-11-01.zip', 'probe_metrology_edges_original.py')]
        for archive, member in members:
            with self.subTest(archive=archive), zipfile.ZipFile(ROOT/'archives'/archive) as z:
                self.assertEqual(z.read(member), PROBE.read_bytes())

    def test_02_archive_hashes_and_manifests(self):
        for row in json.loads((ROOT/'provenance/archive-verification.json').read_text()):
            path = ROOT/'archives'/row['archive']
            bind(path, row['sha256'])
            with zipfile.ZipFile(path) as z:
                filename = 'MANIFEST.sha256' if 'MANIFEST.sha256' in z.namelist() else 'MANIFEST_SHA256.txt'
                for line in z.read(filename).decode().splitlines():
                    if not line.strip() or line.startswith('#'):
                        continue
                    digest, name = line.split(None, 1)
                    self.assertEqual(hashlib.sha256(z.read(name.lstrip('*'))).hexdigest(), digest)

    def test_03_unchanged_historical_program_replays_archived_output(self):
        options = [] if __debug__ else ['-O']
        p = subprocess.run([sys.executable, *options, str(PROBE), '--repo', str(ROOT/'historical_target')],
                           capture_output=True)
        self.assertEqual(p.returncode, 0, p.stderr.decode())
        self.assertEqual(p.stdout, (ROOT/'provenance/original-output.json').read_bytes())

    def test_04_legacy_complete_claim_is_a_failing_negative_control(self):
        options = [] if __debug__ else ['-O']
        p = subprocess.run([sys.executable, *options, str(PROBE), '--repo', str(ROOT/'historical_target'),
                            '--expect-repaired'], capture_output=True)
        self.assertNotEqual(p.returncode, 0)
        self.assertIn(b'Uncertainty completeness defects remain', p.stderr)

    def test_05_original_executed_point_values_and_weights_match_adapter(self):
        original = load_module('original_probe_capture', PROBE)
        sampled = []
        original_moments = original.moments
        def capture(values, weights):
            sampled.append((list(values), list(weights)))
            return original_moments(values, weights)
        original.moments = capture
        argv = sys.argv[:]
        try:
            sys.argv = [str(PROBE), '--repo', str(ROOT/'historical_target')]
            with redirect_stdout(io.StringIO()):
                original.main()
        finally:
            sys.argv = argv
            original.moments = original_moments
        self.assertEqual(len(sampled), 2)
        for name, (original_values, original_weights) in zip(['MAP-21', 'MAP-22'], sampled):
            f = fixture(name)
            values = [m.evaluate(f['expr'], point, f['parameters']) for p, point in f['support']]
            self.assertEqual(values, original_values)
            self.assertEqual([Q(p) for p, point in f['support']], original_weights)

    def test_06_map21_closed_form_and_exact_joint_law(self):
        r = run('MAP-21')
        self.assertEqual(r['output_mean'], '1000000/999999')
        self.assertEqual(r['output_variance'], '1/999998000001000000')
        self.assertEqual(r['jacobian'], ['-1', '1'])
        self.assertEqual(r['input_covariance'], [['1/1000000']*2]*2)
        self.assertGreater(Q(r['output_variance']), 0)

    def test_07_map22_closed_form_and_exact_joint_law(self):
        r = run('MAP-22')
        self.assertEqual(r['output_mean'], '1999999000001/2000000000000')
        self.assertEqual(r['output_variance'], '1000000000001/4000000000000000000000000')
        self.assertEqual(r['jacobian'], ['1', '1'])
        self.assertEqual(Q(r['output_variance'])/Q(r['linearized_variance_diagnostic']),
                         Q(1000000000001, 2000000))

    def test_08_covariance_only_original_models_remain_partial(self):
        for name in ['MAP-21', 'MAP-22']:
            f, r = fixture(name), run(name)
            partial = m.propagate(f['expr'], f['order'], f['parameters'],
                                  means=r['input_mean'], covariance=r['input_covariance'])
            self.assertEqual(partial['uncertainty_status'], 'partial')
            self.assertIsNone(partial['output_mean'])
            self.assertIsNone(partial['output_variance'])
            self.assertEqual(partial['linearized_variance_diagnostic'], r['linearized_variance_diagnostic'])

    def test_09_separate_7_over_8_regression_is_not_original_replay(self):
        r = m.report()['historical_product_regression']
        self.assertEqual((r['output_mean'], r['output_variance']), ('7/8', '1/64'))
        for name in ['MAP-21', 'MAP-22']:
            with self.assertRaisesRegex(ValueError, 'historical result differs'):
                certify(name, fixture(name), r)

    def test_10_parameter_probability_and_dependence_mutations_do_not_certify(self):
        for name in ['MAP-21', 'MAP-22']:
            f = fixture(name)
            altered = deepcopy(f)
            key = 'y' if name == 'MAP-21' else 'ratio'
            altered['support'][0][1][key] = '1/2'
            with self.assertRaisesRegex(ValueError, 'joint law changed'):
                certify(name, altered, m.propagate(**altered))
            altered = deepcopy(f)
            altered['support'] = [(str(Q(1,len(f['support']))), point) for p,point in f['support']]
            if name == 'MAP-21':
                a = PARAMS['a']
                altered['support'] = [('1/4', {'y':str(x),'d':str(y)})
                                      for x in [-a,a] for y in [-a,a]]
            with self.assertRaisesRegex(ValueError, 'joint law changed'):
                certify(name, altered, m.propagate(**altered))

    def test_11_complete_first_order_or_changed_results_do_not_certify(self):
        for name in ['MAP-21', 'MAP-22']:
            result = run(name)
            for key,value in [('output_variance',result['linearized_variance_diagnostic']),
                              ('output_mean','1'),('mean_shift','0'),
                              ('uncertainty_status','complete_first_order_conditional')]:
                changed = deepcopy(result);changed[key] = value
                with self.assertRaisesRegex(ValueError, 'historical result differs'):
                    certify(name, fixture(name), changed)

    def test_12_exact_types_and_normalization_enforced(self):
        for bad in [True, False, 0.5, -1, '0']:
            f = fixture('MAP-21');f['support'][0] = (bad,f['support'][0][1])
            with self.assertRaises(m.ContractError): m.propagate(**f)
        f = fixture('MAP-22');f['support'].pop()
        with self.assertRaises(m.ContractError): m.propagate(**f)

    def test_13_invalid_denominator_rejected_and_source_disagreement_rejected(self):
        f = fixture('MAP-21');f['support'][0][1]['y'] = '-1'
        with self.assertRaises(m.ContractError): m.propagate(**f)
        f = fixture('MAP-21')
        with self.assertRaises(m.ContractError): m.propagate(**f, covariance=[['1','0'],['0','1']])

    def test_14_legitimate_singular_cancellation_is_retained(self):
        r = m.propagate(['sub',['input','end'],['input','start']], ['end','start'], {},
                        means={'end':'7','start':'2'}, covariance=[['4','4'],['4','4']])
        self.assertEqual(r['output_variance'], '0')
        self.assertEqual(r['uncertainty_status'], 'exact_for_declared_affine_model')
        r = m.propagate(['div',['input','x'],['input','x']], ['x'], {},
                        support=[('1/2',{'x':'1'}),('1/2',{'x':'2'})])
        self.assertEqual(r['output_variance'], '0')

    def test_15_independent_decimal_raw_second_moment_checks(self):
        for precision in [50,80,120]:
            with localcontext() as ctx:
                ctx.prec = precision
                def dec(q): return Decimal(q.numerator)/Decimal(q.denominator)
                a,eps,delta = (dec(PARAMS[k]) for k in ['a','eps','delta'])
                observations = {
                    'MAP-21': ([1/(1+x)+x for x in [-a,a]], [Decimal('0.5')]*2),
                    'MAP-22': ([(1+x)*(1-(1-delta)*x) for x in [-eps,Decimal(0),eps]],
                               [Decimal('0.25'),Decimal('0.5'),Decimal('0.25')])}
                for name,(ys,weights) in observations.items():
                    mean = sum(p*y for p,y in zip(weights,ys))
                    variance = sum(p*y*y for p,y in zip(weights,ys))-mean*mean
                    exact_mean,exact_variance,_ = closed_form(name)
                    self.assertLess(abs(mean-dec(exact_mean)), Decimal(10)**(-precision+6))
                    self.assertLess(abs(variance/dec(exact_variance)-1), Decimal(10)**(-precision+25))

    def test_16_local_parameter_sweep_matches_independent_formulas(self):
        for a in [Q(1,2),Q(1,10),Q(1,1000),Q(1,10000)]:
            f=fixture('MAP-21');f['support']=[('1/2',{'y':str(x),'d':str(x)}) for x in [-a,a]]
            r=m.propagate(**f)
            self.assertEqual(Q(r['output_variance']), a**6/(1-a*a)**2)
        eps=PARAMS['eps']
        for delta in [Q(0),Q(1,1000000),Q(1,1000)]:
            f=fixture('MAP-22')
            f['support']=[(str(p),{'ratio':str(1+x),'frequency':str(1-(1-delta)*x)})
                          for x,p in zip([-eps,Q(0),eps],[Q(1,4),Q(1,2),Q(1,4)])]
            r=m.propagate(**f)
            self.assertEqual(Q(r['output_variance']),delta**2*eps**2/2+(1-delta)**2*eps**4/4)

    def test_17_source_changes_invalidate_replay_binding(self):
        with tempfile.TemporaryDirectory() as tmp:
            changed = Path(tmp)/'changed.py'
            changed.write_bytes(PROBE.read_bytes()+b'\n')
            with self.assertRaisesRegex(ValueError, 'source bytes differ'):
                bind(changed, PROBE_HASH)
        bind(PROBE,PROBE_HASH);bind(M3_PATH,M3_HASH)

    def test_18_persisted_report_reconstructs_and_records_remain_unchanged(self):
        report=m.report()
        self.assertEqual(report,json.loads((ROOT/'source/manual/data/m3/mapping_error.json').read_text()))
        self.assertIn('partial',report['historical_probe_status']['fidelity'])


if __name__ == '__main__':
    if '--json' in sys.argv:
        print(json.dumps({'head':'3ffb3c9984eef95ca4b105ac323d249f30412816',
            'original_probe_sha256':PROBE_HASH,'mapping_sha256':M3_HASH,
            'source_parameters':{k:str(v) for k,v in PARAMS.items()},
            'scope':'Exact original synthetic finite laws; no physical calibration or ontology claim',
            'results':{name:run(name) for name in ['MAP-21','MAP-22']}},indent=2,sort_keys=True))
    else:
        unittest.main(verbosity=2)
