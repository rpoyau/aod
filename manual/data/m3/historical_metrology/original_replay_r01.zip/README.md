**AOD MAP-21 / MAP-22 historical replay evidence — 3 November 2026**

Read `REPORT.md` for the individual GO recommendations and scope. This is a detached review package. The pinned source snapshots and historical artifacts are unchanged.

From this directory, with Python 3.12:

```bash
python3 test_historical_replay.py
python3 -O test_historical_replay.py
python3 test_historical_replay.py --json
```

The 18-test suite requires only the standard library. It verifies all three archive hashes/manifests, original probe identity, historical baseline output, current original-law propagation, independent closed forms, decimal cross-checks and hostile controls. Outputs from this review are in `results/`. `tests.txt` summarizes scope and results.

To reproduce the original historical program directly:

```bash
python3 provenance/probe_metrology_edges.py --repo historical_target
python3 -O provenance/probe_metrology_edges.py --repo historical_target
```

Adding `--expect-repaired` must fail on that historical target: it is a negative control demonstrating the two original completeness defects. The full output must match `provenance/original-output.json` byte-for-byte. The included historical target is a five-file dependency snapshot, not a full repository checkout.

With pytest available, the separately preserved upstream mapping suite is reproducible from `source/`:

```bash
python3 -m pytest -q -p no:cacheprovider tests/test_m3_mapping_error.py
python3 -O -m pytest -q -p no:cacheprovider tests/test_m3_mapping_error.py
python3 manual/scripts/aod_mapping_error.py --check
```

The source directory is a scoped pinned snapshot, not a full M3 checkout. It intentionally retains the old partial historical-probe status; no repository update is represented by this package. The original plan and archived reviews also retain their historical statuses.

`MANIFEST.sha256` covers the delivery's files except itself. Do not confuse it with preserved source manifests inside `archives/` and `provenance/`. All three full recovery archives are included so their provenance checks are reproducible offline. Their other historical contents are not new scientific validation.
