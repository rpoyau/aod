# AOD M3 — Cell Measures, Mappings and Error Quantification

M3 · Scientific plan R01 · Designation update 1 · 26 October 2026 · Europe/Zurich

**Disposition:** standalone revision plan, prepared for a new work thread. Scientific implementation and acceptance checks are not executed by this delivery. No repository or GitHub changes are included.

## 0. M3 designation and programme dependencies

**Milestone:** M3 — Cell Measures, Mappings and Error Quantification.

The owner designated this revision M3 on 26 October 2026. R01 remains the scientific plan revision; this update adds its programme position, dependency record and self-contained dated references. The 36 scientific acceptance criteria remain unchanged and unexecuted.

| Milestone or consumer | Relationship to M3 | Binding rule |
|---|---|---|
| M1 — Native Closure-Wave Dynamics and Relational Temporal Comparison | Supplies applicable native definitions, lineage, folding/exposure and relational-time inputs | Reconcile the supplied owner amendment with the current accepted source in WP0; the historical plan does not establish today's accepted head |
| M2 — Awareness | Supplies any awareness-specific dynamics actually used by an M3 application | Bind only when that application uses them; awareness is not a blanket prerequisite for cell measures or general mapping/error mathematics |
| M3 — Cell Measures, Mappings and Error Quantification | Defines the reusable measure, mapping and error contracts, with geometry as the first worked case | Execute WP0–WP7 against explicitly bound inputs and report each claim's scope |
| Manual II / Matter I | Consumes applicable mappings and error contracts for relational-time/SI reporting and atomic comparisons | Bind the consumer separately; an atomic observation law and its relative gain remain distinct scientific obligations |

Main owns supported general mathematics and accepted native definitions. The AOD Manual owns declared models, metrics and worked calculations. Manual II / Matter I consumes those interfaces. Milestone numbering establishes programme identity; it neither certifies M1/M2 completion nor selects a Git branch or release.

The supplied source archive identifies itself as v40.01r10. It and the supplied AFC/General Mechanics archives are packaged as dated reference bytes. Their inclusion does not select the execution base. Primary and consumer commit/tree bindings remain unselected until WP0 reconciles the current accepted sources and intervening owner amendments.

The M1 amendment's closure → recurrence/wave → scoped field → downstream representation order remains binding where applicable. Its typed closure-derived phase-resolvability statement must not silently revert to the earlier native phase-selector formulation. Current source reconciliation records any later accepted change.

Dependency details are recorded in M3_DEPENDENCIES.json. Geometry-specific holds apply only to claims using the missing construction or measure. Temporal/SI integration requires its own admitted recurrent-lineage and observation-map inputs. General mapping/error work and explicitly declared conditional models may proceed as their own dependencies permit.

No Git branch is created by this plan update. Existing remote branch state has not been inspected. Future source work follows START_NEW_THREAD.md: isolated local checkout, preservation of user changes, detached delivery, and no GitHub writes.

## 1. Purpose and completion claim

Derive scoped boundary and interior measures from declared AOD cell constructions, define the mappings that turn those measures and relational temporal records into reported quantities, and quantify what each mapping preserves, changes, approximates or leaves undetermined.

The result is a reusable mapping and error framework. Every application that maps an AOD object to another representation or to an observable uses the relevant contract. Geometry is the first worked case. Relational time and the Cs-133/hydrogen application are consumers of the same framework.

This does not make every application depend on completing every geometry example. A frequency-ratio calculation that does not use a geometric coefficient need not wait for a sphere calculation. A calculation that does use one must bind its derivation, scope and error status. The dependency record, rather than a blanket hold, determines the required upstream evidence.

Completion means that executable examples produce independently reconstructable measures, declared mappings, and supported error or uncertainty statements. A partial result is useful when its missing premise is named. Agreement with a target, successful serialization, or an algebraically forced identity does not establish the missing premise.

## 2. Recovered programme and current authority

This revision resumes the July 2026 Native Phase-Cycle programme. The recovered 15–18 July discussions require faces/folds/cells and literal incidences before circumference, surface and volume; independent discrete analysis and executable verification; and explicit projection into 3D/2D report geometry. The reviewed R02 plan names three results: directional closure, relational temporal anchoring and count-derived projection/error audit.

Historical work request: WR_v41_0_0_native_phase_cell_closure. Historical document: AOD Native Phase-Cycle Program Plan r02 — Reviewed. Its source-definition and release gates describe that historical attempt. They are not automatically the execution base, release version or approval workflow of this revision.

The attached owner-amended closure-wave/relational-time plan dated 25 August 2026 supplies the later constructive order: distinction; certified closure as one native phase; recurrence and wave; scoped field organization; folding/exposure; coupling and relational time; downstream representations and metrology. Preserve its lineage, scope, phase, lag and reflection-coupling-duration distinctions.

At new-thread entry, bind the actual current accepted AOD Main/Manual tree and any intervening accepted amendments. Reconcile them with these owner instructions before deriving a new native claim. Do not reset to a July/August commit merely because an old plan names it. Treat the supplied source archives and the last reviewed Matter I head as dated evidence until their relationship to the selected base is established.

Authority order for this milestone:

1. Current owner instructions, AF and applicable AFC premises.
2. The current accepted AOD source and applicable owner amendments, reconciled explicitly.
3. This plan's declared model and validation contracts.
4. Historical plans, fixtures and review findings as evidence of intended scope or limitations.
5. External mathematics and metrology as declared report/reference models and literature.

Primary revision target: rpoyau/aod. Consumer: rpoyau/aod-manual-volume-2, including Matter I PR #1. No new release number or exact implementation base is assigned here. Bind both repositories separately when implementing an integration.

## 3. Scientific scope and ownership

### 3.1 Preserve the constructive order

Axiom → distinction → induced relations → admitted motifs/closures → recurring wave and scoped field → declared cell/transition model → native measures → mapping → mathematical consequence → calibrated comparison.

This order is a dependency discipline, not an assertion that every measure requires every temporal consumer. A static cell measure can be defined on a declared finite complex. A temporal observable additionally requires the admitted recurrent lineages, contacts and common comparison scope specified by the current relational-time contract.

Main owns accepted ontology and general mathematics with explicit hypotheses. The Manual owns declared metrics, embeddings, model choices, reference implementations, worked examples and metrology. Matter I consumes the resulting interfaces. A Manual fit or a Euclidean verification model cannot silently establish a native AOD cell or physical law.

### 3.2 Distinct objects

Retain distinct types for:

- native address, committed event, cell identity, cell dimension, orientation and incidence;
- closure certificate, returned-event identity, wave lineage, comparison window and directional RCD;
- boundary chain, support set, multiplicity, signed flux and unsigned occupancy;
- native count/weight, report-space length/area/volume, projection and calibration;
- exact constant, numerical approximation, deterministic error bound, standard uncertainty and experimental residual.

Do not identify a Q4 graph witness with a filled four-dimensional cubical complex without supplying the additional faces/cells/incidences. A topological dimension or cell count is not automatically a physical spatial dimension or a metric volume. The native construction does not gain a diagonal, radius or Euclidean norm merely through its drawing.

### 3.3 Preserve scope

Folds retain explicit maps from each inner scope and lineage to the outer construction. Equal outer coordinates do not erase inner identities. Shared faces may cancel in an oriented boundary sum while remaining part of the provenance; that cancellation does not delete occupied cells or authorize double-counting their volume.

No change to element placements, the Matter I chart, source authority, existing skills or unrelated awareness work is implied. Preserve frozen v1 fixtures and the existing causal v2 evidence where they remain consumers.

## 4. Native cell and measure contract

For each fixture declare the finite cells K_d, their generators, oriented incidences, construction history, equivalences, boundary/window and admission status. If a chain complex is claimed, define the boundary maps and verify boundary-of-boundary cancellation. If a fold is claimed to be a chain map, test that its induced maps commute with the boundary maps. Do not impose measure preservation on every fold; state the actual property claimed.

Define a measure from its domain and weights. For example, a declared weighted support measure may have the form

    measure_d(S) = sum over c in S of weight_d(c),

with an explicit policy for repeated visits, overlaps, quotient cells, orientation and shared support. Unit weights provide an exact count within that declared model. Physical or Euclidean weights require an additional map.

Boundary and interior calculations must have separate derivations and computational paths. They may share the frozen input complex and declared conventions. Different identifiers alone are not independent derivations, and two routines calling the same target formula are not independent validation.

Refinement is a declared map between levels with a common comparison object or equivalence. Record changes of weights, cell identities, boundary conventions and scope. An apparent refinement trend obtained by changing the object or fitting new weights at every level is a different experiment.

## 5. Mapping contract used by every consumer

Represent a mapping as a record with:

| Field | Required content |
|---|---|
| Identity | Stable map ID/version, code hash and specification hash |
| Domain | Typed input objects, admissibility, scope, lineage and dimensional conventions |
| Codomain | Output quantity, metric/coordinate convention and unit, if any |
| Law | Executable formula/algorithm; origin of every parameter and weight |
| Provenance | Source bindings, input hashes, construction and observation-map dependencies |
| Structure | Claimed invariances, equivariances, injectivity or many-to-one behaviour |
| Information loss | What cannot be recovered; equivalence class or reconstruction bound where available |
| Resolution | Refinement/window/precision policy and its declared comparison object |
| Error | Exactness claim, bound, distribution, standard uncertainty, or explicitly unknown component |
| Calibration | Reference, realization, exposure/fitting ledger, parameter covariance and applicable corrections |
| Comparison | Frozen prediction identity; separately bound evaluation/reference inputs |
| Status | Claim-specific validity and applicability; no universal PASS field standing for all claims |

Some mappings are exact. For them, record the exactness hypotheses and supporting proof/test. Some are lossy but exact as projections; loss of invertibility is not itself numerical error. Quantify loss against a declared reconstruction task or observable when one exists. Do not manufacture a scalar error for incomparable objects.

Mark irrelevant fields as not applicable with a reason. Mark missing applicable information as unknown. Unknown is neither zero nor an implicit independent contribution.

## 6. Error and uncertainty contract

### 6.1 Separate the sources

| Component | Required treatment |
|---|---|
| Finite arithmetic | Preserve exact integers/rationals or symbolic values when supported; bound rounding introduced by numerical evaluation |
| Finite resolution/refinement | Compare the same declared object across levels; supply a theorem, certified enclosure or explicitly empirical trend |
| Finite observation window | Record phase endpoints, window dependence, missed events, slips, drift and temporal dependence where applicable |
| Mapping/model discrepancy | Define the reference measurand and discrepancy; use supported bounds or a declared model, or leave unknown |
| Calibration/input uncertainty | Use applicable uncertainty and the joint dependence structure, including shared references |
| Propagation approximation | Establish adequacy of linearization or use justified higher-order/full-distribution treatment |
| Numerical solver or Monte Carlo error | Report convergence/precision control separately from physical input uncertainty |
| Experimental comparison | Bind prediction, measurement and cross-covariance; distinguish residual from prediction uncertainty |

A deterministic bound is not a standard deviation. Convert it only under a justified probabilistic model. Exact arithmetic within a finite model does not prove the physical model or eliminate its unknown discrepancies. No finite decimal or rational representation is identical to mathematical pi; an exact pi-based formula may nevertheless describe a different geometry from the finite cell construction.

### 6.2 Dependence and composition

Use parameter/source identities to retain shared uncertainty across composed maps. The same calibration appearing in two stages must not be counted twice or treated as independent. A residual involving prediction and measurement needs their covariance when they share inputs.

For a differentiable declared model, the linearized covariance is J Sigma J-transpose. This expression remains a first-order result until its adequacy is established for the claimed output. Marginal relative uncertainty below a fixed percentage is not, by itself, an adequacy proof. Exact or near sensitivity cancellation, reciprocal denominators and nonlinear mean shifts require explicit attention.

Where a full joint distribution is supplied, use exact finite-support propagation, justified integration or converged Monte Carlo as appropriate. Do not silently assume normality or independence. Means/covariances alone do not generally determine nonlinear output distributions or higher moments.

Retain legitimate exact cancellation in a linear or proven constant-output model. Retain valid singular positive-semidefinite covariance matrices. When adequacy is unresolved, keep the estimate and clearly named linearized diagnostic while marking the unsupported uncertainty claim partial.

For deterministic bounds on composed maps, specify the domains and regularity assumptions before combining them. A prospective general result is given in §7. Do not add unlike errors or apply root-sum-square to deterministic bounds.

### 6.3 Numerical policies

Distinguish cycles, radians and arbitrary report coordinates. Test the declared conversion and increased numerical precision. Mathematical pi/tau are exact report constants; their approximations receive numerical bounds. No universal physical error floor follows merely from irrationality or from expressing a rate as a fraction.

Preserve raw external data and its hashes. Document units, rounding conventions and zero-entry interpretation independently of the raw-byte integrity check. Printed zero covariance does not acquire a broad physical uncertainty merely because of its scientific-notation exponent. Conversely, do not assume exact zero without the stated source/format justification.

Relative error requires an appropriate nonzero reference. For ratios and reciprocals, verify that the relevant domain excludes zero; otherwise represent the resulting unbounded/disconnected set or undefined quantity rather than forcing a finite symmetric uncertainty.

## 7. General Mechanics and AF authoring blocks

Use AF templates for any new formal definition or claim. Do not introduce a new axiom to force a desired geometry. Example of a proposed report-model statement:

**[Scope: a declared pair of normed report spaces and their admissible input set.] Choice MAP-1.** We define f and g as the reference maps and f_tilde and g_tilde as their implemented approximations. The domains include all intermediate images used below. Let b_f bound the error of f_tilde, let b_g uniformly bound the error of g_tilde on the required intermediate domain, and let g be Lipschitz there with constant L_g.

**Corollary MAP-1.** The composed implementation error is at most b_g + L_g b_f. **Derivation.** From Choice MAP-1, insert g(f_tilde(x)), apply the triangle inequality and the declared Lipschitz bound. No independence assumption is used.

This is a proposed conditional mathematical block, not an executed physical error budget. Its manuscript form must include **Setup; Derivation; Specialization; Calibration** when applicable; **Falsification; Provenance; Literature note**. Attach a counterexample for a violated hypothesis. Bind proof references to actual source anchors rather than guessed equation numbers.

## 8. Geometry examples and discriminating controls

### G1 — Smallest supported cell construction

Construct the smallest source-supported example exposing an interior, boundary, orientation and fold. Provide separate enumeration and execution/accessor implementations. If the source supports only a graph, supply any higher-cell completion as a declared verification model until its native status is established.

### G2 — Conditional Euclidean tesseract check

Under a declared Euclidean cubical model with edge length a, check four-volume a^4 and three-dimensional boundary measure 8a^3 by enumeration. Keep those two quantities dimensionally distinct from a three-volume and a two-dimensional surface area. This validates a conventional model/accessor; it does not derive a physical metric from AOD topology.

### G3 — Independent circumference/area audit

Derive the boundary report C_L and interior report A_L from their own cell/incidence calculations, with a separately declared radius report r_L. Evaluate R_CA(L) = C_L r_L - 2 A_L only when the operands have compatible meanings and units.

Keep the historical shared-coefficient control: C = 2 q r and A = q r^2 gives R_CA = 0 for every q. This is a consistency identity and cannot determine q. A positive geometry claim must fail a mutation that substitutes an arbitrary shared coefficient while preserving that identity.

### G4 — Refinement and metric mismatch

Include a declared axial staircase comparison. A monotone quarter path with coordinate displacements r and r has total axial length 2r; four such quarters have length 8r. If the intended reference is a Euclidean circle, refining the staircase without changing its length rule does not turn that boundary length into 2 pi r. An area approximation and a boundary-length approximation require separate convergence arguments.

This is a verification-model counterexample, not an assertion that every AOD construction has an axial metric. It tests that the audit can identify a mismatch of metric or estimator, rather than blaming numerical pi precision.

### G5 — Fold, orientation and projection

Use an inner-to-outer fold with retained lineage and scope maps. Check exposed boundary, shared-face cancellation, overlap/multiplicity handling and any claimed chain-map property. A many-to-one projected picture must not merge distinct native vertices or certify native closure. Include anisotropic/orientation-dependent cases before generalizing a single symmetric result.

### G6 — Sphere/hypersphere extension

Open this extension after the dimension, cell complex, measure and projection are defined. Derive coefficients from actual construction counts or declared weighted measures. Freeze the estimator and refinement rule before reference comparison. Record a finite-level result even when a limiting theorem is unavailable; do not label a finite trend a proven continuum limit.

## 9. Relational time and the SI consumer

The native input remains the scoped comparison of admitted recurrent lineages, including cadence, signed phase bias, unwrapped lag, drift, contacts and directional RCD. Native event counts do not receive seconds by naming them time.

A declared atomic observation map may produce reference-equivalent cycles C_A(W). In an ideal constant-reference specialization, the elapsed-time report is C_A(W)/nu_A. Nonconstant frequency, endpoint phase and experimental corrections belong to the complete measurement model rather than being hidden in this simplified expression.

Cs-133 supplies the exact defining SI frequency. A practical Cs realization contributes its applicable uncertainty; a hydrogen anchor uses an SI-traceable calibrated frequency and its covariance. Add device uncertainties only when that realization is actually used. Do not create uncertainty for an exact defining constant or suppress uncertainty from an actual realization.

Matter I's scientific endpoint remains an AOD-derived H/Cs ratio under one declared atomic state-to-observable law. With Cs as scale, nu_H_pred = R_AOD * Delta_nu_Cs. Using measured hydrogen to choose an otherwise free relative gain is calibration/fitting, not an independent hydrogen prediction. The geometry milestone does not automatically determine that atomic law.

The transition period 1/nu_H_pred is distinct from an elapsed interval across a measured window and is not a second independent validation. Keep hydrogen's prior exposure retrospective. Freeze prediction and comparison artifacts separately. Changing evaluation-only hydrogen data must leave the prediction unchanged; a predeclared meaningful dynamics intervention must change the selected observable when the claimed causal model entails it.

Existing stateful simulations and conventional benchmarks can proceed under explicit conditional maps. Each identifies which result is supported: internal dynamics, mapping arithmetic, calibrated comparison or independent prediction.

## 10. Work packages and deliverables

| Package | Work | Required result |
|---|---|---|
| WP0 — Bind and reconcile | Inspect current accepted sources and skills, bind commits/trees and documents, map historical requirements to active definitions | SOURCE_BINDINGS; AUTHORITY_AND_DELTA; dependency map; scoped file list |
| WP1 — Cells and measures | Construct supported cells/incidences, boundary/interior measures, folds and lineage-preserving maps | CELL_MEASURE_SPEC; independent calculations; finite certificates |
| WP2 — Mapping interface | Implement typed maps, provenance, composition, loss/applicability and consumer dependencies | MAPPING_REGISTRY; MAP_CONTRACT schema; composition examples |
| WP3 — Geometry and refinement | Execute G1–G5; open G6 only with its stated premises | GEOMETRY_LEDGER; refinement records; counterexamples and scoped findings |
| WP4 — Error and uncertainty | Implement exact/bounded/distributional/unknown outcomes, covariance sharing and nonlinear adequacy | ERROR_BUDGET schema; propagation results; finite-support oracles |
| WP5 — Temporal/atomic integration | Bind actual relational records and current Cs/H interfaces; keep missing atomic law explicit | SI_CONSUMER_RECORD; prediction/comparison bindings; exposure ledger |
| WP6 — Source revision | Add only supported general results to Main and worked calculations to the Manual; update consumers and skills if justified | Focused detached patch; paired publications; conservation map |
| WP7 — Review and handoff | Run meaningful tests, mutations, reproductions and scientific review; classify each claim | Acceptance matrix; report; patch replay; SHA-256 manifest; compact bundle |

WP0 precedes scientific claims. The generic mapping/error interface and declared verification models can progress while a specific native completion is unresolved. Hold only the dependent claim and name the missing premise. These packages do not require subagents; a future thread may use them only if separately requested by the user or applicable instructions.

## 11. Acceptance, validation and scope reporting

The accompanying ACCEPTANCE.csv defines 36 planned criteria. All begin PLANNED_NOT_EXECUTED. An implementation must report each criterion's exact scope, inputs, evidence and outcome. Do not count a schema test, a synthetic fixture or a conventional benchmark as a native/physical prediction.

Meaningful validation includes exact finite examples, an independently implemented boundary/interior route, orientation and fold controls, bad-projection mutations, the two supplied nonlinear-metrology counterexamples, legitimate cancellation controls, joint-covariance tests and evaluation-data isolation.

Use normal and optimized Python for checkers where removed assertions could change validation. Use exact or high-precision independent oracles where justified. Run relevant existing repository tests and required publication checks for actual manuscript changes. Broaden testing only when a changed dependency or unresolved concern warrants it.

Before/after conservation records cover source bindings, unrelated scientific content, existing skills, Main/Manual cross-references, and Matter I placements/chart when that consumer is touched. Do not silently overwrite historical fixtures, rewrite result labels or replace existing outputs with newly fitted ones.

Acceptance can establish a conditional model, demonstrate a failure, or identify a specific unresolved premise. A falsified proposed invariant does not become an accepted physical result. A clean reproducible negative result is a valid scientific deliverable.

## 12. New-thread execution and delivery

This delivery plans the revision. The accompanying START_NEW_THREAD.md is a ready-to-paste work request for a later thread. It directs an isolated implementation and detached review package; it does not authorize current repository/GitHub writes. Preserve any user changes in future worktrees. Do not merge, force-push, reset Main or publish a release.

At execution entry record the selected primary and consumer commits/trees, installed skills and current owner amendments. The previous review of Matter I at f2dcf01450d5443ba83d207adfade9a27d3d2a7f is historical context, not a claim about the live head at future entry.

Deliver source patch, concise scientific report, active-source/relocation map, data and reproducible calculations, scoped acceptance results, test logs, paired PDFs when manuscript changes require them, and checksums. Every ZIP must be below 20,000,000 bytes. Split by complete logical parts if needed; provide a manifest and reassembly instructions where relevant.

Governance details belong in the plan/evidence. Keep the manuscript compact: define each object once, place each calculation at its proper layer, and avoid repetitive defensive prose.

## 13. Literature note and evidence limits

Mathematical pi and its analytic definition: NIST DLMF §3.12, https://dlmf.nist.gov/3.12 . SI definition: BIPM, https://www.bipm.org/en/si-base-units/second . Practical realization: BIPM/CCTF, https://www.bipm.org/documents/20126/41489667/SI-App2-second.pdf/3c76fec8-04d9-f484-5c3c-a2e280a0f248 . Nonlinear models and propagation: JCGM 100:2008/Amd.1:2026, https://www.bipm.org/documents/20126/2071204/JCGM_100_Amd1_2026.pdf/ ; JCGM 101:2008, https://www.bipm.org/documents/20126/2071204/JCGM_101_2008_E.pdf ; JCGM GUM-6:2020, https://www.bipm.org/documents/20126/2071204/JCGM_GUM_6_2020.pdf .

These references were consulted during the preceding discussion on 26 October 2026. This plan does not reproduce or claim a new validation of their datasets. Current binding and claim-specific source verification remain WP0 work. Historical circle records are scaffolding; the metrology probes demonstrate synthetic approximation limitations. No new cell-volume derivation, atomic prediction or physical calibration was executed in preparing this plan.
